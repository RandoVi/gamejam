extends Camera2D

## Fixed-screen camera.
##
## The level is one continuous map. The camera view is a fixed, screen-sized
## cell: it stays perfectly still until the player leaves that cell, then snaps
## instantly to the cell the player entered. No room nodes, gates, fades or
## scene loads are involved; only the camera changes.
##
## Cell (0, 0) starts at grid_origin. A cell is exactly one camera view, so the
## camera bounds themselves are the "areas" the player moves between.

## The node followed by the camera (the player).
@export var target_path: NodePath = NodePath("..")

## Size of one fixed view. Vector2.ZERO uses the current viewport size.
@export var cell_size: Vector2 = Vector2.ZERO

## World position of the top-left corner of cell (0, 0).
@export var grid_origin: Vector2 = Vector2.ZERO

@export var grid_start: Node2D

## How far outside the current cell the player must go before the camera
## switches. A small value prevents flicker when walking along the border.
@export var exit_margin: float = 2.0

var _target: Node2D
var _size: Vector2
var _cell: Vector2i

func _ready() -> void:
	position_smoothing_enabled = false
	limit_smoothed = false
	drag_horizontal_enabled = false
	drag_vertical_enabled = false
	top_level = true
	
	limit_left = -10000000
	limit_top = -10000000
	limit_right = 10000000
	limit_bottom = 10000000
	
	make_current()

	_target = get_node_or_null(target_path) as Node2D
	_update_size()
	
	# Use SpawnPoint as the center of camera cell (0, 0).
	if grid_start:
		grid_origin = grid_start.global_position - _size * 0.5
		
	get_viewport().size_changed.connect(_on_viewport_resized)
	if _target:
		_cell = _cell_at(_target.global_position)
		_snap_to(_cell)

func _update_size() -> void:
	# What the camera actually sees = viewport size divided by zoom.
	var base := cell_size if cell_size != Vector2.ZERO else get_viewport_rect().size
	_size = base / zoom

func _on_viewport_resized() -> void:
	_update_size()
	if _target:
		_snap_to(_cell)

func _physics_process(_delta: float) -> void:
	if _target == null:
		return
	
	# Still inside the current fixed view: do nothing at all.
	if _cell_rect(_cell).grow(exit_margin).has_point(_target.global_position):
		return
	
	# The player has left this view. Switch to the cell they entered.
	var next := _cell_at(_target.global_position)
	if next != _cell:
		_cell = next
		_snap_to(next)

func _cell_at(point: Vector2) -> Vector2i:
	return Vector2i(
			floori((point.x - grid_origin.x) / _size.x),
			floori((point.y - grid_origin.y) / _size.y))

func _cell_rect(cell: Vector2i) -> Rect2:
	return Rect2(grid_origin + Vector2(cell) * _size, _size)

func _cell_center(cell: Vector2i) -> Vector2:
	return grid_origin + (Vector2(cell) + Vector2(0.5, 0.5)) * _size

func _snap_to(cell: Vector2i) -> void:
	# Keep the view inside the level. Camera2D limits are view edges, so the
	# centre is clamped by half a view.
	var half: Vector2 = _size * 0.5
	var pos: Vector2 = _cell_center(cell)
	
	if limit_left > -10000000.0:
		pos.x = maxf(pos.x, limit_left + half.x)
	if limit_right < 10000000.0:
		pos.x = minf(pos.x, limit_right - half.x)
	if limit_top > -10000000.0:
		pos.y = maxf(pos.y, limit_top + half.y)
	if limit_bottom < 10000000.0:
		pos.y = minf(pos.y, limit_bottom - half.y)
	
	global_position = pos
	reset_smoothing()
