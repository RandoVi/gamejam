	
	Playful Inputs UI Kit (1.0)

	Created/distributed by Amaury Hauler x Head Quarters (https://amauryh.itch.io/)
	Creation date: 10-30-2026

	Support by crediting 'AmauryH' or "Head Quarters" or 'amauryh.itch.io' (much appreciated, not mandatory)

			______________________________

	CONTENT:

	- 2 themes: 
	Dark Theme & Light Theme

	- 8 categories:
		> Generic (42 different elements)
		> Joysticks (56 different elements)
		> Keyboard & Mouse (106 different elements)
		> Playstation (41 different elements)
		> SteamDeck (38 different elements)
		> Switch (19 different elements)
		> Touchpads (24 different elements)
		> Xbox (30 different elements)

	- 2 files types: 
	SVG & PNG

	- Each element in 5 sizes for PNG:
	32px, 64px, 128px, 256px, 512px

			______________________________

	FONT USED: 

	Super Joyful. by fsuarez913 on Dafont (free for personal & commercial use)
	https://www.dafont.com/fr/super-joyful.font

			______________________________
	
	• Website: amauryh.itch.io
	• Show us your work, leave a comment!
		> amauryh.itch.io/playful-inputs-ui-kit
	
	The kit is delivered "as is" and may not get any updates. Only time will tell, take care :)
	If you bought this kit or parts of this kit on any website, know that there is a full free version elsewhere.