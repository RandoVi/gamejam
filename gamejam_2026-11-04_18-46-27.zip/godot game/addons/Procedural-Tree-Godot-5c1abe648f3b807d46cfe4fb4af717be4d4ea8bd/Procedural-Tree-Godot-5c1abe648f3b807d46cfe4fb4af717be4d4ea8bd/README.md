# Procedural Pixel Art Tree Generator for Godot 4

A single `@tool` script that generates procedural pixel art trees, crystals, corals, cacti, and more — directly in the Godot editor. No external dependencies. Just drop it in your project.

<p align="center">
  <img src="screenshots/sakura.png" width="30%" />
  <img src="screenshots/birch.png" width="20%" />
  <img src="screenshots/willow.png" width="30%" />
</p>
<p align="center">
  <img src="screenshots/crystal.png" width="18%" />
  <img src="screenshots/baobab.png" width="24%" />
  <img src="screenshots/coral.png" width="18%" />
  <img src="screenshots/stalactite.png" width="15%" />
</p>

## Features

### Trunk
- **Random height/width**: min/max ranges for natural variation across instances
- **Tapering** with configurable curve (linear, fast taper, stays thick)
- **Quadratic curve** and **sinusoidal waves** (vines, twisted trunks)
- **Profile shaping**: bulge (baobab), rings (bamboo, palm), roughness (rocks, stalagmites)
- **Texture support**: single or multi-texture (birch bark, etc.)
- **Gradient shading**: same positional gradient + hue shift as foliage applied to trunk

### Branches
- **Leonardo rule** with recursive sub-branches (configurable depth)
- **Solid w*w rendering** per segment (no staircase artifacts)
- **Directional shading** perpendicular to branch direction (adapts at elbows)
- **Draw order toggle**: behind or in front of trunk
- **Zone control**: start/end ratio on trunk, anchor inset depth
- **Taper curve**: same as trunk, configurable per branch
- **Rounding**: square to circular cross-section (Chebyshev to Euclidean blend)
- **Edge shading**: symmetric light/dark for crystal/cylinder effects
- **Elbow with angle**: bend at configurable point, second segment follows the configured angle
- **Per-branch hue shift**: every branch tip gets the same warm hue regardless of Y position
- **Glow**: halo around trunk + branches with real PointLight2D

### Foliage
- **Procedural blobs** (random walk) or **custom leaf textures**
- **4 canopy shapes**: round (oak), triangular (pine), flat (acacia), columnar (cypress)
- **Vertical gradient** + **hue shifting** (3-color palette, pro pixel art look)
- **Edge scatter** for organic silhouette
- **Spatial hash grid** for consistent leaf spacing
- **Crown fill**, branch density, and trunk leaf controls

### Rendering
- **Baked textures** at runtime: 7 textures (1 trunk + 3 bg leaf bands + 3 fg leaf bands) — only 7 draw calls instead of hundreds
- **Wind sway** with player interaction + **editor preview animation** toggle
- **Shading variation**: per-instance random offset on gradient/hue shift for natural variety
- **Configurable outline** (color, thickness)
- **Light rays** through the canopy
- **Screen culling** via VisibleOnScreenNotifier2D
- **Falling leaves** particle support (optional CPUParticles2D child)

## Quick Start

1. Copy `ProceduralTree.gd` into your Godot 4 project
2. Create a new `Node2D` scene and attach the script
3. Tweak parameters in the Inspector — everything updates in real-time

Or open the included `procedural_tree.tscn` scene directly.

## What Can You Make?

| Type | Key Parameters |
|------|---------------|
| **Oak tree** | Round canopy, medium trunk, short branches |
| **Pine / Fir** | Triangular canopy, tall trunk, angled branches |
| **Birch** | Trunk texture, thin trunk, white bark |
| **Sakura** | Pink foliage, scatter, falling leaves particles |
| **Weeping Willow** | Negative branch angles, long branches, flat canopy |
| **Cactus** | No foliage, thick trunk, branch_elbow, 2-3 branches |
| **Crystal cluster** | No foliage, glow, many branches, branch_round, edge_shading |
| **Coral** | Short trunk, many branches, depth 2-3, vibrant colors |
| **Stalagmite** | No branches, trunk_roughness, no foliage |
| **Baobab** | trunk_bulge, wide base, flat canopy |

## Parameters Overview

The script exposes **50+ parameters** organized in groups in the Inspector:
- **Tronc** (Trunk) — height, width, tapering, curve, waves, profile, colors, texture
- **Branches** — count, length, angle, width, depth, zone, taper, rounding, glow
- **Feuillage** (Foliage) — textures, radius, density, canopy shape, gradient, hue shift, scatter
- **Rendu** (Rendering) — outline, baking, wind sway, light rays, seed

Every parameter has a setter that regenerates the tree in real-time in the editor.

## Requirements

- **Godot 4.3+** (tested on 4.4 and 4.6)
- No plugins, no dependencies, no autoloads
- Works with any renderer (Forward+, Mobile, Compatibility)

## Tips

- Set `texture_filter` to **Nearest** in your project settings for crisp pixel art
- Use `tree_tint` with a darker color for background trees (parallax depth)
- Add a `CPUParticles2D` child named `"FallingLeaves"` for leaf particle effects
- The `seed` parameter (0 = use position) ensures trees are unique but deterministic
- Disable `shadow_enabled` on the generated PointLight2D for better performance

## License

MIT — use it however you want, credit appreciated.
