@tool
class_name ProceduralTree
extends Node2D

## Procedural pixel art tree/bush.
## Trunk + branches drawn via _draw() with 3-color shading.
## Foliage = leaf cluster sprites placed around branches,
## split into 2 layers (back/front) for depth.
## Inspired by archaicvirus/TreeGenerator.

# =============================================
#              TRUNK
# =============================================
@export_group("Trunk")
@export_range(2, 256) var trunk_height_min: int = 16:
	set(v):
		trunk_height_min = v
		if trunk_height_max < v:
			trunk_height_max = v
		_generate_tree()
		queue_redraw()
@export_range(2, 256) var trunk_height_max: int = 16:
	set(v):
		trunk_height_max = v
		if trunk_height_min > v:
			trunk_height_min = v
		_generate_tree()
		queue_redraw()
@export_range(1, 100) var trunk_width_min: int = 2:
	set(v):
		trunk_width_min = v
		if trunk_width_max < v:
			trunk_width_max = v
		_generate_tree()
		queue_redraw()
@export_range(1, 100) var trunk_width_max: int = 2:
	set(v):
		trunk_width_max = v
		if trunk_width_min > v:
			trunk_width_min = v
		_generate_tree()
		queue_redraw()
## Trunk width at top (tapering). Set < trunk_width for cone, > for inverted baobab.
@export_range(1, 100) var trunk_width_top: int = 1:
	set(v):
		trunk_width_top = v
		_generate_tree()
		queue_redraw()
## Taper curve (1 = linear, <1 = narrows fast, >1 = stays thick longer)
@export_range(0.2, 4.0, 0.1) var trunk_taper_curve: float = 1.0:
	set(v):
		trunk_taper_curve = v
		_generate_tree()
		queue_redraw()
## Quadratic curvature (-64 = left, 64 = right)
@export_range(-64.0, 64.0, 0.5) var trunk_curve: float = 0.0:
	set(v):
		trunk_curve = v
		_generate_tree()
		queue_redraw()
## Number of sine wave undulations (vines, twisted trunks)
@export_range(0, 10) var trunk_wave_count: int = 0:
	set(v):
		trunk_wave_count = v
		_generate_tree()
		queue_redraw()
## Wave amplitude (pixels)
@export_range(0.0, 16.0, 0.5) var trunk_wave_amplitude: float = 3.0:
	set(v):
		trunk_wave_amplitude = v
		_generate_tree()
		queue_redraw()

@export_subgroup("Trunk Profile")
## Bulge position (0 = base, 0.5 = middle, 1 = top). Useful for baobab, palm tree.
@export_range(0.0, 1.0, 0.05) var trunk_bulge_pos: float = 0.0:
	set(v):
		trunk_bulge_pos = v
		_generate_tree()
		queue_redraw()
## Extra thickness at bulge point (px)
@export_range(0, 16) var trunk_bulge_amount: int = 0:
	set(v):
		trunk_bulge_amount = v
		_generate_tree()
		queue_redraw()
## Bulge spread (0.1 = very sharp, 0.8 = very wide)
@export_range(0.1, 0.8, 0.05) var trunk_bulge_spread: float = 0.35:
	set(v):
		trunk_bulge_spread = v
		_generate_tree()
		queue_redraw()
## Number of rings along the trunk (palm, bamboo, column)
@export_range(0, 30) var trunk_rings: int = 0:
	set(v):
		trunk_rings = v
		_generate_tree()
		queue_redraw()
## Ring depth in pixels
@export_range(0.0, 3.0, 0.1) var trunk_rings_depth: float = 1.0:
	set(v):
		trunk_rings_depth = v
		_generate_tree()
		queue_redraw()
## Trunk roughness — random width variation per pixel (rocks, stalagmites)
@export_range(0.0, 3.0, 0.1) var trunk_roughness: float = 0.0:
	set(v):
		trunk_roughness = v
		_generate_tree()
		queue_redraw()

@export_subgroup("Colors")
@export var trunk_color_light: Color = Color(0.55, 0.38, 0.26):
	set(v):
		trunk_color_light = v
		queue_redraw()
@export var trunk_color_mid: Color = Color(0.42, 0.28, 0.18):
	set(v):
		trunk_color_mid = v
		queue_redraw()
@export var trunk_color_dark: Color = Color(0.30, 0.18, 0.10):
	set(v):
		trunk_color_dark = v
		queue_redraw()
## Apply the same positional gradient as foliage (gradient + hue shift) to trunk/branches
@export var trunk_gradient_shading: bool = false:
	set(v):
		trunk_gradient_shading = v
		queue_redraw()
## Optional trunk texture (repeats vertically, e.g. birch).
## If empty, uses the classic 3-color shading.
@export var trunk_texture: Texture2D = null:
	set(v):
		trunk_texture = v
		_trunk_image = v.get_image() if v else null
		queue_redraw()
## List of textures that alternate on the trunk (overrides trunk_texture if non-empty).
## Each texture covers trunk_tex_height pixels then switches to the next.
@export var trunk_textures: Array[Texture2D] = []:
	set(v):
		trunk_textures = v
		_trunk_images.clear()
		for tex in v:
			if tex:
				_trunk_images.append(tex.get_image())
			else:
				_trunk_images.append(null)
		queue_redraw()
## Height in pixels before switching texture (0 = texture's own height).
@export_range(0, 64) var trunk_tex_height: int = 0:
	set(v):
		trunk_tex_height = v
		queue_redraw()

var _trunk_image: Image = null
var _trunk_images: Array[Image] = []

@export_group("Tint")
## Global tree tint (white = no change, dark = background tree).
@export var tree_tint: Color = Color.WHITE:
	set(v):
		tree_tint = v
		modulate = v

# =============================================
#              BRANCHES
# =============================================
@export_group("Branches")

@export_range(0, 32) var branch_count: int = 2:
	set(v):
		branch_count = v
		_generate_tree()
		queue_redraw()
@export_range(2, 64) var branch_length_min: int = 4:
	set(v):
		branch_length_min = v
		_generate_tree()
		queue_redraw()
@export_range(2, 64) var branch_length_max: int = 8:
	set(v):
		branch_length_max = v
		_generate_tree()
		queue_redraw()
@export_range(-180.0, 180.0) var branch_angle_min: float = 25.0:
	set(v):
		branch_angle_min = v
		_generate_tree()
		queue_redraw()
@export_range(-180.0, 180.0) var branch_angle_max: float = 55.0:
	set(v):
		branch_angle_max = v
		_generate_tree()
		queue_redraw()
@export_range(1, 30) var branch_width: int = 1:
	set(v):
		branch_width = v
		queue_redraw()
@export_range(1, 5) var branch_depth: int = 1:
	set(v):
		branch_depth = v
		_generate_tree()
		queue_redraw()
## Start ratio: where branches begin on the trunk (0 = base, 1 = top)
@export_range(0.0, 1.0) var branch_start_ratio: float = 0.4:
	set(v):
		branch_start_ratio = v
		_generate_tree()
		queue_redraw()
## End ratio: where branches stop on the trunk (0 = base, 1 = top)
@export_range(0.0, 1.0) var branch_end_ratio: float = 1.0:
	set(v):
		branch_end_ratio = v
		_generate_tree()
		queue_redraw()
## Anchor point inset into the trunk (0 = edge, 1 = trunk center)
@export_range(0.0, 1.0, 0.05) var branch_inset: float = 0.0:
	set(v):
		branch_inset = v
		_generate_tree()
		queue_redraw()
## Shorten branches toward the top (0 = all same, 1 = top ones very short)
@export_range(0.0, 1.0, 0.05) var branch_length_taper: float = 0.0:
	set(v):
		branch_length_taper = v
		_generate_tree()
		queue_redraw()
## Branch taper curve (1 = linear, <1 = thins fast, >1 = stays thick longer)
@export_range(0.2, 4.0, 0.1) var branch_taper_curve: float = 1.0:
	set(v):
		branch_taper_curve = v
		_generate_tree()
		queue_redraw()
## Max branch height (px). 0 = no limit. For clusters (corals, crystals).
@export_range(0, 128) var branch_height_max: int = 0:
	set(v):
		branch_height_max = v
		_generate_tree()
		queue_redraw()
## Branch elbow (cactus). 0 = straight, 0.3 = elbow at 1/3, 0.5 = at middle.
@export_range(0.0, 0.8, 0.05) var branch_elbow: float = 0.0:
	set(v):
		branch_elbow = v
		_generate_tree()
		queue_redraw()
## Round branch edges (0 = square, 1 = round/cylindrical)
@export_range(0.0, 1.0, 0.05) var branch_round: float = 0.0:
	set(v):
		branch_round = v
		queue_redraw()
## Symmetric shading: light edges, dark center (cylinder/crystal effect)
@export var branch_edge_shading: bool = false:
	set(v):
		branch_edge_shading = v
		queue_redraw()
## Draw branches behind the trunk (true) or in front (false)
@export var branch_behind_trunk: bool = true:
	set(v):
		branch_behind_trunk = v
		queue_redraw()

@export_subgroup("Glow")
## Glow color around the tree (crystals, glowing mushrooms). Also creates a PointLight2D.
@export var branch_glow_color: Color = Color(0.5, 0.8, 1.0, 0.4):
	set(v):
		branch_glow_color = v
		queue_redraw()
## Glow intensity (0 = disabled)
@export_range(0.0, 1.0, 0.05) var branch_glow_intensity: float = 0.0:
	set(v):
		branch_glow_intensity = v
		queue_redraw()

# =============================================
#              FOLIAGE
# =============================================
@export_group("Foliage")
## Enable/disable foliage (dead tree if false)
@export var foliage_enabled: bool = true:
	set(v):
		foliage_enabled = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Leaf cluster textures (hand-drawn sprites, 8x8 or similar).
## If empty, procedural blobs are generated automatically.
@export var leaf_textures: Array[Texture2D] = []:
	set(v):
		leaf_textures = v
		_generate_tree()
		queue_redraw()
## Crown radius around branch endpoints
@export_range(4, 64) var crown_radius: int = 12:
	set(v):
		crown_radius = v
		_generate_tree()
		queue_redraw()
## Number of leaves per branch endpoint
@export_range(2, 40) var leaves_per_branch: int = 8:
	set(v):
		leaves_per_branch = v
		_generate_tree()
		queue_redraw()
## Number of leaves to fill the crown (around the top)
@export_range(0, 100) var crown_fill_count: int = 15:
	set(v):
		crown_fill_count = v
		_generate_tree()
		queue_redraw()
## Density along branches (0 = tips only, 1 = everywhere)
@export_range(0.0, 1.0, 0.1) var branch_leaf_density: float = 0.5:
	set(v):
		branch_leaf_density = v
		_generate_tree()
		queue_redraw()
## Leaves along the trunk (fills the central gap)
@export_range(0, 30) var trunk_leaf_count: int = 0:
	set(v):
		trunk_leaf_count = v
		_generate_tree()
		queue_redraw()
## Crown vertical offset
@export var crown_offset: Vector2 = Vector2(0, -4):
	set(v):
		crown_offset = v
		_generate_tree()
		queue_redraw()

@export_subgroup("Canopy Shape")
## Shape: ROUND (oak), TRIANGULAR (spruce), FLAT (acacia), COLUMNAR (cypress)
enum CanopyShape { ROUND, TRIANGULAR, FLAT, COLUMNAR }
@export var canopy_shape: CanopyShape = CanopyShape.ROUND:
	set(v):
		canopy_shape = v
		_generate_tree()
		queue_redraw()

@export_subgroup("Depth & Gradient")
## Vertical gradient: darkens the bottom of the canopy (0 = uniform, 2 = very pronounced)
@export_range(0.0, 2.0, 0.05) var foliage_gradient: float = 0.3:
	set(v):
		foliage_gradient = v
		queue_redraw()
## Hue shifting: shifts hue for shadows (toward blue) and highlights (toward yellow).
## 0 = no shift (brightness only), 1 = pronounced shift. Pro pixel art look.
@export_range(0.0, 2.0, 0.05) var hue_shift_amount: float = 0.0:
	set(v):
		hue_shift_amount = v
		queue_redraw()
## Random shading variation per tree (0 = identical, 2 = very varied).
## Slightly offsets gradient and hue shift based on seed.
@export_range(0.0, 2.0, 0.05) var shading_variation: float = 0.0:
	set(v):
		shading_variation = v
		queue_redraw()
## Minimum spacing between clusters (pixels). Higher = more visible separation.
@export_range(0, 8) var cluster_min_spacing: int = 2:
	set(v):
		cluster_min_spacing = v
		_generate_tree()
		queue_redraw()

@export_subgroup("Edge Details")
## Small isolated pixels around canopy edges (0 = none)
@export_range(0, 30) var scatter_amount: int = 5:
	set(v):
		scatter_amount = v
		_generate_tree()
		queue_redraw()
## Colors for procedural blobs (used if leaf_textures is empty)
@export_subgroup("Procedural Colors")
@export var foliage_color_light: Color = Color(0.35, 0.65, 0.25):
	set(v):
		foliage_color_light = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
@export var foliage_color_mid: Color = Color(0.22, 0.50, 0.18):
	set(v):
		foliage_color_mid = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
@export var foliage_color_dark: Color = Color(0.14, 0.35, 0.12):
	set(v):
		foliage_color_dark = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
@export_subgroup("Blob Generation")
## Number of different leaf shapes per tree
@export_range(3, 40) var leaf_blob_count: int = 5:
	set(v):
		leaf_blob_count = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Size of each blob in pixels
@export_range(4, 32) var leaf_blob_size: int = 8:
	set(v):
		leaf_blob_size = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Number of random walk steps (more = denser blob). 0 = auto based on size.
@export_range(0, 200) var leaf_blob_steps: int = 0:
	set(v):
		leaf_blob_steps = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Upward bias (0 = symmetric, 1 = very pointy upward)
@export_range(0.0, 1.0, 0.05) var leaf_blob_bias_up: float = 0.0:
	set(v):
		leaf_blob_bias_up = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Percentage of interior pixels removed (holes in foliage)
@export_range(0.0, 0.6, 0.05) var leaf_blob_holes: float = 0.0:
	set(v):
		leaf_blob_holes = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Size variation between blobs (0 = all same, 1 = very varied)
@export_range(0.0, 1.0, 0.05) var leaf_blob_steps_variation: float = 0.3:
	set(v):
		leaf_blob_steps_variation = v
		_proc_textures_dirty = true
		_generate_tree()
		queue_redraw()
## Global black outline around the entire foliage silhouette
@export var foliage_outline: bool = false:
	set(v):
		foliage_outline = v
		_generate_tree()
		queue_redraw()

# =============================================
#              OUTLINE
# =============================================
@export_group("Outline")
@export var outline_enabled: bool = false:
	set(v):
		outline_enabled = v
		queue_redraw()
@export var outline_color: Color = Color.BLACK:
	set(v):
		outline_color = v
		queue_redraw()

# =============================================
#              LIGHT RAYS
# =============================================
@export_group("Light Rays")
@export var light_rays_enabled: bool = false:
	set(v):
		light_rays_enabled = v
		_generate_tree()
		queue_redraw()
## Number of rays (3-8 is enough)
@export_range(1, 12) var light_rays_count: int = 4:
	set(v):
		light_rays_count = v
		_generate_tree()
		queue_redraw()
## Ray angle in degrees (0 = vertical, -30 = sun from left)
@export_range(-60.0, 60.0, 1.0) var light_rays_angle: float = -15.0:
	set(v):
		light_rays_angle = v
		_generate_tree()
		queue_redraw()
## Ray length (in pixels below entry point)
@export_range(8, 80) var light_rays_length: int = 30:
	set(v):
		light_rays_length = v
		_generate_tree()
		queue_redraw()
## Ray width at the base (in pixels)
@export_range(1, 8) var light_rays_width: int = 2:
	set(v):
		light_rays_width = v
		_generate_tree()
		queue_redraw()
## Ray opacity
@export_range(0.0, 0.5, 0.02) var light_rays_opacity: float = 0.15:
	set(v):
		light_rays_opacity = v
		queue_redraw()
## Ray color
@export var light_rays_color: Color = Color(1.0, 0.95, 0.7):
	set(v):
		light_rays_color = v
		queue_redraw()

# =============================================
#              ANIMATION
# =============================================
@export_group("Animation")
## Preview sway animation in the editor
@export var editor_preview_animation: bool = false:
	set(v):
		editor_preview_animation = v
		if Engine.is_editor_hint():
			set_process(v)
			if not v:
				queue_redraw()
@export_range(0.3, 3.0) var sway_speed: float = 1.0
@export_range(0.5, 4.0) var sway_amplitude: float = 1.5
@export_range(0.5, 5.0) var sway_decay: float = 1.5

var _leaf_particles: CPUParticles2D = null

# =============================================
#              GENERATION
# =============================================
@export_group("Generation")
@export var tree_seed: int = 0:
	set(v):
		tree_seed = v
		if v != 0:
			_effective_seed = v
		_generate_tree()
		queue_redraw()

# =============================================
#              INTERNALS
# =============================================

# Resolved values from seed (min/max → concrete value)
var trunk_height: int = 16
var trunk_width: int = 2
# Per-tree shading offset (computed from shading_variation + seed)
var _shading_offset: float = 0.0

# Trunk and branch segments [{x, y, width, is_trunk, depth}]
var _segments: Array = []
# Branch data for leaf placement [{segments: Array, depth: int}]
var _branch_data: Array = []
# Trunk top position
var _trunk_top: Vector2 = Vector2.ZERO

# Leaf placements: {pos: Vector2, layer: int (0=bg, 1=fg), tex_idx: int}
var _leaf_placements: Array = []

# Procedural textures generated if no sprites provided
var _proc_leaf_textures: Array[ImageTexture] = []
var _proc_textures_dirty: bool = true

var _effective_seed: int = 0
var _canopy_min_y: float = 0.0  # Highest Y (negative)
var _canopy_max_y: float = 0.0  # Lowest Y
var _canopy_min_x: float = 0.0  # Leftmost X
var _canopy_max_x: float = 0.0  # Rightmost X
var _branch_zone_top_y: float = 0.0   # Highest branch Y
var _branch_zone_bottom_y: float = 0.0 # Lowest branch Y
# Pre-computed light rays: Array of PackedVector2Array (triangles)
var _light_rays: Array[PackedVector2Array] = []
var _time: float = 0.0
var _on_screen: bool = true

# Spatial grid for O(1) spacing check instead of O(n²)
var _spacing_grid: Dictionary = {}

# Global foliage outline (silhouette)
var _foliage_outline_tex: ImageTexture = null
var _foliage_outline_offset: Vector2 = Vector2.ZERO

# Real PointLight2D for glow (runtime)
var _glow_light: PointLight2D = null

# ===== BAKE (runtime optimization) =====
var _baked: bool = false
var _baked_trunk: ImageTexture = null
var _baked_leaves_bg: Array[ImageTexture] = []  # 3 bandes (low, mid, high)
var _baked_leaves_fg: Array[ImageTexture] = []  # 3 bandes (low, mid, high)
var _bake_offset: Vector2 = Vector2.ZERO  # coin haut-gauche de la bounding box
var _bake_size: Vector2i = Vector2i.ZERO
const BAKE_BANDS := 3
var _band_sway_factors: Array[float] = [1.0, 0.66, 0.33]
var _band_y_ranges: Array[Vector2] = []  # [Vector2(y_min, y_max)] pour chaque bande


func _ready() -> void:
	add_to_group("vegetation")
	if tree_seed != 0:
		_effective_seed = tree_seed
	else:
		_effective_seed = get_instance_id()

	_generate_proc_textures()
	_generate_tree()
	_time = float(_effective_seed % 1000) / 100.0
	modulate = tree_tint

	# Editor: process only if preview animation is enabled
	if Engine.is_editor_hint():
		set_process(editor_preview_animation)
		return

	# Runtime only
	if not Engine.is_editor_hint():
		# Bake the tree into textures for runtime (massive optimization)
		_bake_all_layers()
		var total_height := trunk_height + crown_radius * 2 + 16
		var total_width := trunk_width + branch_length_max * 2 + crown_radius * 2 + 16
		var notifier := VisibleOnScreenNotifier2D.new()
		notifier.rect = Rect2(
			-total_width / 2.0, -total_height - 8,
			total_width, total_height + 16
		)
		add_child(notifier)
		notifier.screen_entered.connect(func():
			_on_screen = true
			set_process(true)
			queue_redraw()
			if _leaf_particles: _leaf_particles.emitting = true
			if _glow_light: _glow_light.visible = true
		)
		notifier.screen_exited.connect(_on_screen_exited)
		set_process(false)

		# Real PointLight2D for glow (runtime only)
		if branch_glow_intensity > 0.0:
			_glow_light = PointLight2D.new()
			_glow_light.color = branch_glow_color
			_glow_light.energy = branch_glow_intensity * 3.0
			_glow_light.shadow_enabled = false
			_glow_light.position = Vector2(0, float(-trunk_height) * 0.5)
			var grad_tex := GradientTexture2D.new()
			var gradient := Gradient.new()
			gradient.set_color(0, Color.WHITE)
			gradient.set_color(1, Color(1, 1, 1, 0))
			grad_tex.gradient = gradient
			grad_tex.fill = GradientTexture2D.FILL_RADIAL
			grad_tex.fill_from = Vector2(0.5, 0.5)
			grad_tex.fill_to = Vector2(0.5, 0.0)
			grad_tex.width = 64
			grad_tex.height = 64
			_glow_light.texture = grad_tex
			_glow_light.texture_scale = float(trunk_height + branch_length_max) / 32.0
			add_child(_glow_light)

	# Look for a child CPUParticles2D named "FallingLeaves" placed in the scene
	_leaf_particles = get_node_or_null("FallingLeaves") as CPUParticles2D


func _on_screen_exited() -> void:
	_on_screen = false
	set_process(false)
	queue_redraw()  # Redraw vide pour effacer les commandes
	if _leaf_particles:
		_leaf_particles.emitting = false
	if _glow_light:
		_glow_light.visible = false


# =============================================
#     PROCEDURAL TEXTURES (if no sprites)
# =============================================

func _generate_proc_textures() -> void:
	## Generates leaf blobs via random walk with auto-shading.
	## Each blob has a unique sub-seed → different shapes per tree.
	if not foliage_enabled:
		_proc_leaf_textures.clear()
		_proc_textures_dirty = false
		return
	if not _proc_textures_dirty and _proc_leaf_textures.size() > 0:
		return
	_proc_leaf_textures.clear()

	var sz := leaf_blob_size
	var neighbors: Array[Vector2i] = [Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, -1), Vector2i(0, 1)]
	var diags: Array[Vector2i] = [Vector2i(-1, -1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(1, 1)]

	# Auto steps: if 0, compute ~60% of blob surface
	var base_steps := leaf_blob_steps
	if base_steps == 0:
		base_steps = roundi(float(sz * sz) * 0.6)

	for blob_i in leaf_blob_count:
		var rng := RandomNumberGenerator.new()
		rng.seed = _effective_seed * 1000 + blob_i * 137 + 7

		# --- Size variation between blobs ---
		var variation_range := leaf_blob_steps_variation * float(base_steps) * 0.5
		var actual_steps := maxi(5, roundi(float(base_steps) + rng.randf_range(-variation_range, variation_range)))

		# --- Step 1: Random walk with directional bias ---
		var filled: Dictionary = {}
		var center := Vector2i(sz / 2, sz / 2)
		filled[center] = true

		var candidates: Dictionary = {}
		for n: Vector2i in neighbors:
			var np: Vector2i = center + n
			if np.x >= 0 and np.x < sz and np.y >= 0 and np.y < sz:
				candidates[np] = true

		for _step in actual_steps:
			if candidates.is_empty():
				break

			# With upward bias: prefer candidates with smaller y (higher)
			var keys: Array = candidates.keys()
			var pick: Vector2i
			if leaf_blob_bias_up > 0.0 and rng.randf() < leaf_blob_bias_up:
				# Pick the highest candidate (smallest y)
				var best_y: int = sz + 1
				var best_candidates: Array[Vector2i] = []
				for k: Variant in keys:
					var kv: Vector2i = k
					if kv.y < best_y:
						best_y = kv.y
						best_candidates.clear()
						best_candidates.append(kv)
					elif kv.y == best_y:
						best_candidates.append(kv)
				pick = best_candidates[rng.randi_range(0, best_candidates.size() - 1)]
			else:
				pick = keys[rng.randi_range(0, keys.size() - 1)]

			filled[pick] = true
			candidates.erase(pick)
			for n: Vector2i in neighbors:
				var np: Vector2i = pick + n
				if np.x >= 0 and np.x < sz and np.y >= 0 and np.y < sz:
					if not filled.has(np) and not candidates.has(np):
						candidates[np] = true

		# --- Step 1b: Holes — remove interior pixels ---
		if leaf_blob_holes > 0.0:
			var interior: Array[Vector2i] = []
			for pixel_pos: Vector2i in filled:
				var surrounded := true
				for n: Vector2i in neighbors:
					if not filled.has(pixel_pos + n):
						surrounded = false
						break
				if surrounded:
					interior.append(pixel_pos)
			# Remove a % of interior pixels
			var to_remove := roundi(float(interior.size()) * leaf_blob_holes)
			for _h in to_remove:
				if interior.is_empty():
					break
				var idx := rng.randi_range(0, interior.size() - 1)
				filled.erase(interior[idx])
				interior.remove_at(idx)

		# --- Step 2: Auto-shading based on neighbors ---
		var img := Image.create(sz, sz, false, Image.FORMAT_RGBA8)
		img.fill(Color(0, 0, 0, 0))

		# Global shading: all blobs in uniform mid color,
		# positional gradient is applied at draw/bake time
		for pixel_pos: Vector2i in filled:
			img.set_pixel(pixel_pos.x, pixel_pos.y, foliage_color_mid)

		var tex := ImageTexture.create_from_image(img)
		_proc_leaf_textures.append(tex)

	_proc_textures_dirty = false


func _get_leaf_texture(idx: int) -> Texture2D:
	## Returns the leaf sprite to use (provided or procedural).
	if leaf_textures.size() > 0:
		return leaf_textures[idx % leaf_textures.size()]
	if _proc_leaf_textures.size() > 0:
		return _proc_leaf_textures[idx % _proc_leaf_textures.size()]
	return null


func _get_leaf_variant_count() -> int:
	if leaf_textures.size() > 0:
		return leaf_textures.size()
	return _proc_leaf_textures.size()


# =============================================
#              TREE GENERATION
# =============================================

func _generate_tree() -> void:
	_segments.clear()
	_branch_data.clear()
	_leaf_placements.clear()

	if _proc_textures_dirty:
		_generate_proc_textures()

	var rng := RandomNumberGenerator.new()
	rng.seed = _effective_seed if _effective_seed != 0 else randi()

	# Resolve random values (min/max → concrete value for this seed)
	trunk_height = rng.randi_range(trunk_height_min, trunk_height_max)
	trunk_width = rng.randi_range(trunk_width_min, trunk_width_max)
	# Per-tree shading variation: random offset applied to gradient
	_shading_offset = rng.randf_range(-shading_variation, shading_variation) * 0.15 if shading_variation > 0.0 else 0.0

	# 0. Trunk texture map (randomized with seed)
	_build_trunk_tex_map()

	# 1. Trunk
	_generate_trunk(rng)

	# 2. Branches (stores segments + per-branch data)
	if branch_count > 0 and trunk_height > 4:
		_generate_branches(rng)

	# 2b. Compute the vertical zone covered by branches
	_branch_zone_top_y = _trunk_top.y
	_branch_zone_bottom_y = _trunk_top.y
	for bd in _branch_data:
		var end_y: float = bd["end_pos"].y
		if end_y < _branch_zone_top_y:
			_branch_zone_top_y = end_y
		if end_y > _branch_zone_bottom_y:
			_branch_zone_bottom_y = end_y
		for seg_pos: Vector2 in bd["segments"]:
			if seg_pos.y < _branch_zone_top_y:
				_branch_zone_top_y = seg_pos.y
			if seg_pos.y > _branch_zone_bottom_y:
				_branch_zone_bottom_y = seg_pos.y

	# 3. Place leaves around branches + crown
	if foliage_enabled:
		_place_leaves(rng)

	# 4. Light rays (pre-computed once)
	_light_rays.clear()
	if foliage_enabled and light_rays_enabled:
		_generate_light_rays(rng)

	# 5. Global foliage outline
	if foliage_enabled and foliage_outline:
		_compute_foliage_outline()
	else:
		_foliage_outline_tex = null


func _generate_trunk(rng: RandomNumberGenerator) -> void:
	for py in trunk_height:
		var t := float(py) / float(trunk_height - 1) if trunk_height > 1 else 0.0
		# Sine wave undulation + quadratic curvature
		var wave_offset := 0.0
		if trunk_wave_count > 0:
			wave_offset = sin(t * float(trunk_wave_count) * TAU) * trunk_wave_amplitude
		var curve_offset := trunk_curve * t * t + wave_offset
		var w := _calc_trunk_width(t, rng)
		# Center the trunk despite width changes
		var center_offset := (float(trunk_width) - float(w)) * 0.5
		_segments.append({
			"x": roundf(curve_offset + center_offset),
			"y": float(-py),
			"width": w,
			"is_trunk": true,
			"depth": 0,
		})
	var top_curve := trunk_curve * 1.0
	_trunk_top = Vector2(roundf(top_curve), float(-trunk_height))


func _calc_trunk_width(t: float, rng: RandomNumberGenerator) -> int:
	## Computes trunk width at position t (0=base, 1=top).
	## Combines taper, bulge, rings and roughness.

	# Taper with curve: pow(t, curve) → 1=linear, >1=stays thick longer, <1=narrows fast
	var t_curved := pow(t, trunk_taper_curve) if trunk_taper_curve != 1.0 else t
	var w := lerpf(float(trunk_width), float(trunk_width_top), t_curved)

	# Rounded bulge (baobab, palm, bottle) — cosine curve for smooth shape
	if trunk_bulge_amount > 0:
		var dist := absf(t - trunk_bulge_pos)
		var spread := maxf(trunk_bulge_spread, 0.05)
		if dist < spread:
			var bulge_t := (cos(dist / spread * PI) + 1.0) * 0.5  # cloche lisse
			w += float(trunk_bulge_amount) * bulge_t

	# Rings (palm, bamboo, column)
	if trunk_rings > 0 and trunk_rings_depth > 0.0:
		w += sin(t * float(trunk_rings) * TAU) * trunk_rings_depth

	# Roughness (rocks, stalagmites, organic trunks)
	if trunk_roughness > 0.0:
		w += rng.randf_range(-trunk_roughness, trunk_roughness)

	return maxi(1, roundi(w))


func _generate_branches(rng: RandomNumberGenerator) -> void:
	## Branches distributed along the trunk, alternating left/right.
	## Each branch attaches to a trunk vertex.

	# Collect trunk segments to attach branches to
	var trunk_segs: Array[Dictionary] = []
	for seg in _segments:
		if seg["is_trunk"]:
			trunk_segs.append(seg)

	if trunk_segs.size() < 3:
		return

	# Distribute branches along the trunk between start and end ratio
	var start_idx := roundi(float(trunk_segs.size() - 1) * branch_start_ratio)
	var end_idx := roundi(float(trunk_segs.size() - 1) * branch_end_ratio)
	end_idx = clampi(end_idx, start_idx + 1, trunk_segs.size() - 1)
	var available := end_idx - start_idx
	if available < 1:
		return

	for i in branch_count:
		# Alternate left/right
		var going_right := (i % 2 == 0)

		# Attachment position on the trunk
		var attach_ratio := float(i + 1) / float(branch_count + 1)
		var seg_idx := start_idx + roundi(attach_ratio * float(available))
		seg_idx = clampi(seg_idx + rng.randi_range(-1, 1), start_idx, end_idx)
		var seg := trunk_segs[seg_idx]
		var sx: float = seg["x"]
		var sy: float = seg["y"]
		var seg_w: int = seg["width"]
		# Attach to the correct side of the trunk, with optional inset
		var inset := float(seg_w) * branch_inset * 0.5
		var start_x := sx + (float(seg_w) - inset if going_right else inset)
		var start := Vector2(start_x, sy)

		# Height ratio of this branch (0 = bottom, 1 = top)
		var height_ratio := attach_ratio

		# Compute trunk local angle at this attachment point
		var trunk_angle_local := 0.0
		if seg_idx > 0 and seg_idx < trunk_segs.size():
			var prev := trunk_segs[seg_idx - 1]
			var curr := trunk_segs[seg_idx]
			trunk_angle_local = atan2(float(curr["y"]) - float(prev["y"]), float(curr["x"]) - float(prev["x"]))

		_generate_single_branch(rng, start, going_right, 1, -1.0, trunk_angle_local, height_ratio)


func _generate_single_branch(rng: RandomNumberGenerator, start: Vector2, going_right: bool, depth: int, parent_width: float = -1.0, trunk_angle: float = 0.0, height_ratio: float = 0.5) -> void:
	## Branch: advances pixel by pixel perpendicular to the trunk.
	## Thickness decreases from trunk to tip (tapering).
	if depth > branch_depth:
		return

	# Thickness (Leonardo da Vinci: decreases with each generation)
	var w_float := parent_width if parent_width > 0 else float(branch_width)
	if depth > 1:
		w_float *= 0.65

	# Length in pixels — shorten toward top based on branch_length_taper
	var length := rng.randi_range(branch_length_min, branch_length_max)
	if branch_length_taper > 0.0 and depth == 1:
		# height_ratio: 0 = bas (longues), 1 = haut (courtes)
		var taper_factor := 1.0 - height_ratio * branch_length_taper
		length = maxi(2, roundi(float(length) * taper_factor))
	if depth > 1:
		length = maxi(3, roundi(float(length) * rng.randf_range(0.45, 0.65)))

	var dir_x := 1.0 if going_right else -1.0

	# Branch direction via trigonometry
	# 0° = horizontal, 90° = straight up, negative = drooping
	var angle_deg := rng.randf_range(branch_angle_min, branch_angle_max)
	var angle_rad := deg_to_rad(angle_deg)
	var step_x := cos(angle_rad)   # horizontal component (always ≥0 for 0-90°)
	var step_y := -sin(angle_rad)  # vertical component (negative = up in Godot)

	# Deviation due to trunk curve
	var trunk_lean := 0.0
	if depth == 1 and absf(trunk_angle + PI / 2.0) > 0.01:
		trunk_lean = cos(trunk_angle) * 0.5

	var branch_segments: Array[Vector2] = []
	var cx := start.x
	var cy := start.y
	var prev_pos := Vector2(roundf(cx), roundf(cy))

	# Elbow: compute two directions (before/after elbow)
	# Before elbow: horizontal (X component of angle only)
	# After elbow: the configured angle (step_x, step_y)
	var elbow_pre_sx := 1.0
	var elbow_pre_sy := 0.0
	var elbow_post_sx := step_x
	var elbow_post_sy := step_y
	if branch_elbow > 0.0 and absf(step_x) > 0.01:
		# Normalize the post-elbow part to keep the same speed
		var post_len := sqrt(elbow_post_sx * elbow_post_sx + elbow_post_sy * elbow_post_sy)
		if post_len > 0.01:
			elbow_post_sx /= post_len
			elbow_post_sy /= post_len

	for px in length:
		# Elbow: first part horizontal, second part follows the angle
		var local_sx := step_x
		var local_sy := step_y
		if branch_elbow > 0.0:
			var progress := float(px) / float(maxi(length - 1, 1))
			if progress < branch_elbow:
				local_sx = elbow_pre_sx
				local_sy = elbow_pre_sy
			else:
				local_sx = elbow_post_sx
				local_sy = elbow_post_sy

		# Stepper
		cx += dir_x * local_sx + trunk_lean
		cy += local_sy

		# Height max: clamp the height
		if branch_height_max > 0 and depth == 1:
			var max_y := start.y - float(branch_height_max)
			if cy < max_y:
				cy = max_y

		# Slight random variation
		if rng.randf() < 0.15:
			cy += rng.randf_range(-1.0, 0.5)

		var pos := Vector2(roundf(cx), roundf(cy))

		# Shading direction: perpendicular to local direction
		# shade_v = true → horizontal branch → shade by row (dy)
		# shade_v = false → vertical branch → shade by column (dx)
		var shade_v := absf(local_sx) >= absf(local_sy)

		# Tapering with curve (same principle as trunk_taper_curve)
		var t := float(px) / float(length - 1) if length > 1 else 1.0
		var t_curved := pow(t, branch_taper_curve) if branch_taper_curve != 1.0 else t
		var seg_w := maxi(1, roundi(lerpf(w_float, maxf(1.0, w_float * 0.5), t_curved)))

		# Fill gaps: interpolate if jump > 1px in Chebyshev distance
		var gap_dx := absi(roundi(pos.x - prev_pos.x))
		var gap_dy := absi(roundi(pos.y - prev_pos.y))
		var gap_max := maxi(gap_dx, gap_dy)
		if gap_max > 1 and branch_segments.size() > 0:
			for s in range(1, gap_max):
				var gt := float(s) / float(gap_max)
				var interp := Vector2(
					roundf(lerpf(prev_pos.x, pos.x, gt)),
					roundf(lerpf(prev_pos.y, pos.y, gt))
				)
				branch_segments.append(interp)
				_segments.append({
					"x": interp.x, "y": interp.y,
					"width": seg_w, "is_trunk": false,
					"depth": depth, "shade_v": shade_v,
					"branch_t": t,
				})

		branch_segments.append(pos)
		_segments.append({
			"x": pos.x, "y": pos.y,
			"width": seg_w, "is_trunk": false,
			"depth": depth, "shade_v": shade_v,
			"branch_t": t,
		})
		prev_pos = pos

	var end_pos := branch_segments[branch_segments.size() - 1] if branch_segments.size() > 0 else start

	_branch_data.append({
		"segments": branch_segments,
		"depth": depth,
		"end_pos": end_pos,
	})

	# Sub-branches
	if depth < branch_depth and branch_segments.size() > 4:
		var sub_count := rng.randi_range(1, maxi(1, 3 - depth))
		for _s in sub_count:
			# Attach between 40% and 85% of the branch
			var attach_idx := rng.randi_range(
				branch_segments.size() * 2 / 5,
				branch_segments.size() * 17 / 20
			)
			attach_idx = clampi(attach_idx, 0, branch_segments.size() - 1)
			var attach_pos := branch_segments[attach_idx]
			# Sub-branches can go in either direction
			# but prefer the same direction as parent
			var sub_right := going_right if rng.randf() > 0.3 else not going_right
			_generate_single_branch(rng, attach_pos, sub_right, depth + 1, w_float)


func _generate_light_rays(rng: RandomNumberGenerator) -> void:
	## Pre-computes light ray triangles.
	## Finds points in the canopy without nearby leaves,
	## and draws a triangle downward with the configured angle.
	if _leaf_placements.is_empty():
		return

	var crown_center := _trunk_top + crown_offset
	var angle_rad := deg_to_rad(light_rays_angle)
	var direction := Vector2(sin(angle_rad), 1.0).normalized()  # vers le bas + angle

	# Grid of leaf positions to test for "gaps"
	var leaf_set: Dictionary = {}
	var cell_size := float(leaf_blob_size) * 0.8  # grid resolution
	if cell_size < 2.0:
		cell_size = 2.0
	for leaf in _leaf_placements:
		var lpos: Vector2 = leaf["pos"]
		var gx := roundi(lpos.x / cell_size)
		var gy := roundi(lpos.y / cell_size)
		leaf_set[Vector2i(gx, gy)] = true

	# Find gaps: points in the canopy without a leaf in the cell
	var gap_points: Array[Vector2] = []
	var search_rng := RandomNumberGenerator.new()
	search_rng.seed = _effective_seed * 777 + 42

	# Randomly sample the canopy to find gaps
	var attempts := light_rays_count * 20
	for _i in attempts:
		if gap_points.size() >= light_rays_count:
			break
		var test_pos := _sample_canopy_point(search_rng, crown_center)
		var gx := roundi(test_pos.x / cell_size)
		var gy := roundi(test_pos.y / cell_size)
		# Is this point a "gap"? (no leaf in the cell or direct neighbors)
		var has_leaf := leaf_set.has(Vector2i(gx, gy))
		if not has_leaf:
			# Check we're not too far from a leaf (must be a real gap, not outside)
			var near_leaf := false
			for dx in range(-2, 3):
				for dy in range(-2, 3):
					if leaf_set.has(Vector2i(gx + dx, gy + dy)):
						near_leaf = true
						break
				if near_leaf:
					break
			if near_leaf:
				# Check spacing with other gap_points
				var too_close := false
				var min_gap := float(light_rays_length) * 0.4
				for existing in gap_points:
					if test_pos.distance_to(existing) < min_gap:
						too_close = true
						break
				if not too_close:
					gap_points.append(test_pos)

	# If not enough natural gaps, place some distributed across the canopy
	if gap_points.size() < light_rays_count:
		for _i in light_rays_count - gap_points.size():
			var pos := _sample_canopy_point(search_rng, crown_center)
			gap_points.append(pos)

	# Build the triangles
	for gap in gap_points:
		var half_w := float(light_rays_width) * 0.5
		var top_left := gap + Vector2(-half_w, 0.0)
		var top_right := gap + Vector2(half_w, 0.0)
		# The ray widens slightly toward the bottom
		var bottom_center := gap + direction * float(light_rays_length)
		var spread := half_w + float(light_rays_length) * 0.08
		var bottom_left := bottom_center + Vector2(-spread, 0.0)
		var bottom_right := bottom_center + Vector2(spread, 0.0)

		var triangle := PackedVector2Array([
			Vector2(roundf(top_left.x), roundf(top_left.y)),
			Vector2(roundf(top_right.x), roundf(top_right.y)),
			Vector2(roundf(bottom_right.x), roundf(bottom_right.y)),
			Vector2(roundf(bottom_left.x), roundf(bottom_left.y)),
		])
		_light_rays.append(triangle)


func _place_leaves(rng: RandomNumberGenerator) -> void:
	## Places leaves around EACH branch and trunk top.
	## Each branch endpoint = a leaf cluster.
	## Leaves along branches create coverage.
	## No canopy shape constraint on direct placement —
	## shape comes naturally from branch structure.

	var variant_count := _get_leaf_variant_count()
	if variant_count == 0:
		return

	var crown_center := _trunk_top + crown_offset
	_init_spacing_grid()

	# Compensate bias_up: offset blobs downward to cover branches
	var bias_offset_y := leaf_blob_bias_up * float(leaf_blob_size) * 0.3

	# A) Leaf cluster at EACH branch endpoint (with retries)
	for bd in _branch_data:
		var end_pos: Vector2 = bd["end_pos"]
		var depth: int = bd["depth"]
		var tip_count := maxi(3, leaves_per_branch / depth)
		var cluster_radius := float(crown_radius) * 0.7 / float(depth)

		for _i in tip_count:
			var placed := false
			for _retry in 4:
				var angle := rng.randf() * TAU
				var dist := sqrt(rng.randf()) * cluster_radius
				var pos := end_pos + Vector2(
					roundf(cos(angle) * dist),
					roundf(sin(angle) * dist * 0.7 + bias_offset_y)
				)
				if _check_spacing(pos):
					var layer := 0 if rng.randf() > 0.5 else 1
					_leaf_placements.append({
						"pos": pos,
						"layer": layer,
						"tex_idx": rng.randi_range(0, variant_count - 1),
						"depth": depth,
					})
					_add_to_spacing_grid(pos)
					placed = true
					break
			if not placed:
				rng.randi()  # avancer le RNG pour garder la seed stable

	# B) Feuilles le long des branches
	for bd in _branch_data:
		var segs: Array = bd["segments"]
		var depth: int = bd["depth"]
		if segs.size() == 0:
			continue

		for si in range(segs.size() - 1, -1, -1):
			var dist_from_tip := segs.size() - 1 - si
			var place_chance := 1.0 - float(dist_from_tip) / float(segs.size()) * (1.0 - branch_leaf_density)
			if rng.randf() > place_chance:
				continue

			var seg_pos: Vector2 = segs[si]
			var placed := false
			for _retry in 3:
				var offset := Vector2(rng.randf_range(-4, 4), rng.randf_range(-4, 2) + bias_offset_y)
				var pos := seg_pos + offset
				if _check_spacing(pos):
					var layer := 0 if rng.randf() > 0.5 else 1
					_leaf_placements.append({
						"pos": pos,
						"layer": layer,
						"tex_idx": rng.randi_range(0, variant_count - 1),
						"depth": depth,
					})
					_add_to_spacing_grid(pos)
					placed = true
					break
			if not placed:
				rng.randi()

	# C) Remplissage couronne (avec retries pour meilleur remplissage)
	for _i in crown_fill_count:
		var placed := false
		for _retry in 5:
			var pos := _sample_canopy_point(rng, crown_center)
			if _check_spacing(pos):
				var layer := 0 if rng.randf() > 0.5 else 1
				_leaf_placements.append({
					"pos": pos,
					"layer": layer,
					"tex_idx": rng.randi_range(0, variant_count - 1),
					"depth": 0,
				})
				_add_to_spacing_grid(pos)
				placed = true
				break
		if not placed:
			rng.randi()

	# D) Feuilles le long du tronc principal (comble le trou central)
	if trunk_leaf_count > 0:
		var trunk_top_y := _trunk_top.y
		var trunk_start_y := trunk_top_y + float(trunk_height) * branch_start_ratio
		var trunk_zone_height := trunk_start_y - trunk_top_y
		if trunk_zone_height > 1.0:
			for _i in trunk_leaf_count:
				var t := rng.randf()
				var py := trunk_top_y + t * trunk_zone_height
				var height_t := 1.0 - (py / float(-trunk_height)) if trunk_height > 0 else 0.0
				var cx := trunk_curve * height_t * height_t
				var spread := float(crown_radius) * 0.35
				var ox := rng.randf_range(-spread, spread)
				var pos := Vector2(roundf(cx + ox), roundf(py))
				pos = _constrain_to_canopy(pos, crown_center)

				if not _check_spacing(pos):
					continue

				var layer := 0 if rng.randf() > 0.4 else 1
				_leaf_placements.append({
					"pos": pos,
					"layer": layer,
					"tex_idx": rng.randi_range(0, variant_count - 1),
					"depth": 0,
				})
				_add_to_spacing_grid(pos)

	# E) Scatter — small isolated pixels at edges
	if scatter_amount > 0 and _leaf_placements.size() > 0:
		_add_scatter_leaves(rng, crown_center, variant_count)

	# F) Calculer les bornes XY pour le gradient et le shading global
	_canopy_min_y = 0.0
	_canopy_max_y = 0.0
	_canopy_min_x = 0.0
	_canopy_max_x = 0.0
	for leaf in _leaf_placements:
		var lpos: Vector2 = leaf["pos"]
		if lpos.y < _canopy_min_y:
			_canopy_min_y = lpos.y
		if lpos.y > _canopy_max_y:
			_canopy_max_y = lpos.y
		if lpos.x < _canopy_min_x:
			_canopy_min_x = lpos.x
		if lpos.x > _canopy_max_x:
			_canopy_max_x = lpos.x


func _sample_canopy_point(rng: RandomNumberGenerator, center: Vector2) -> Vector2:
	## Samples a point in the canopy based on its shape.
	var angle := rng.randf() * TAU
	var distance := sqrt(rng.randf()) * float(crown_radius)

	match canopy_shape:
		CanopyShape.ROUND:
			return center + Vector2(
				roundf(cos(angle) * distance),
				roundf(sin(angle) * distance * 0.7)
			)
		CanopyShape.TRIANGULAR:
			# Spruce: point at top, wide at bottom
			# Uses the full branch zone (not just crown_radius)
			var tri_top := _branch_zone_top_y - 4.0  # un peu au-dessus
			var tri_bottom := _branch_zone_bottom_y + 2.0
			var tri_height := tri_bottom - tri_top
			if tri_height < 4.0:
				tri_height = float(crown_radius) * 2.0
				tri_top = center.y - tri_height
				tri_bottom = center.y
			# Sample Y : 0 = pointe (haut), 1 = base (bas)
			var t_y := rng.randf()
			t_y = sqrt(t_y)  # biais vers le bas (plus de surface en bas)
			var y_pos := tri_top + t_y * tri_height
			# Width proportional to vertical position
			var max_width := float(crown_radius) * t_y * 1.3
			var x_pos := rng.randf_range(-max_width, max_width)
			# Center X on the trunk curve at this height
			var trunk_x := 0.0
			if trunk_height > 0:
				var h_t := clampf(-y_pos / float(trunk_height), 0.0, 1.0)
				trunk_x = trunk_curve * h_t * h_t
			return Vector2(roundf(trunk_x + x_pos), roundf(y_pos))
		CanopyShape.FLAT:
			# Wide horizontally, flattened vertically (acacia)
			return center + Vector2(
				roundf(cos(angle) * distance * 1.5),
				roundf(sin(angle) * distance * 0.35)
			)
		CanopyShape.COLUMNAR:
			# Narrow, elongated vertically (cypress)
			return center + Vector2(
				roundf(cos(angle) * distance * 0.4),
				roundf(sin(angle) * distance * 1.3)
			)
	return center


func _is_in_canopy_shape(pos: Vector2, center: Vector2) -> bool:
	## Checks if a point is within the canopy shape.
	var rel := pos - center
	var r := float(crown_radius)
	if r < 1.0:
		return true

	match canopy_shape:
		CanopyShape.ROUND:
			return (rel.x * rel.x) / (r * r) + (rel.y * rel.y) / (r * 0.7 * r * 0.7) <= 1.5
		CanopyShape.TRIANGULAR:
			# Uses the branch zone for the triangle
			var tri_top := _branch_zone_top_y - 4.0
			var tri_bottom := _branch_zone_bottom_y + 2.0
			var tri_height := tri_bottom - tri_top
			if tri_height < 4.0:
				tri_height = r * 2.0
			# t: 0 = pointe (haut), 1 = base (bas)
			var t := clampf((pos.y - tri_top) / tri_height, 0.0, 1.0)
			var max_x := r * t * 1.3
			return absf(pos.x - center.x) <= max_x * 1.3 and pos.y >= tri_top - 2.0 and pos.y <= tri_bottom + 2.0
		CanopyShape.FLAT:
			return (rel.x * rel.x) / (r * 1.5 * r * 1.5) + (rel.y * rel.y) / (r * 0.35 * r * 0.35) <= 1.5
		CanopyShape.COLUMNAR:
			return (rel.x * rel.x) / (r * 0.4 * r * 0.4) + (rel.y * rel.y) / (r * 1.3 * r * 1.3) <= 1.5
	return true


func _constrain_to_canopy(pos: Vector2, center: Vector2) -> Vector2:
	## If the point is outside the canopy shape, pulls it back inside.
	## For ROUND, no strong constraint (shape comes from branches).
	if canopy_shape == CanopyShape.ROUND:
		return pos

	var rel := pos - center
	var r := float(crown_radius)
	if r < 1.0:
		return pos

	match canopy_shape:
		CanopyShape.TRIANGULAR:
			# Triangle based on the branch zone
			var tri_top := _branch_zone_top_y - 4.0
			var tri_bottom := _branch_zone_bottom_y + 2.0
			var tri_height := tri_bottom - tri_top
			if tri_height < 4.0:
				tri_height = r * 2.0
			# Clamp Y
			if pos.y < tri_top:
				pos.y = tri_top
			if pos.y > tri_bottom:
				pos.y = tri_bottom
			# t: 0 = pointe, 1 = base
			var t := clampf((pos.y - tri_top) / tri_height, 0.0, 1.0)
			var max_width := r * t * 1.3
			if max_width < 1.0:
				max_width = 1.0
			# Center X on the trunk curve
			var trunk_x := 0.0
			if trunk_height > 0:
				var h_t := clampf(-pos.y / float(trunk_height), 0.0, 1.0)
				trunk_x = trunk_curve * h_t * h_t
			var dx := pos.x - trunk_x
			if absf(dx) > max_width:
				pos.x = trunk_x + signf(dx) * max_width
			return Vector2(roundf(pos.x), roundf(pos.y))
		CanopyShape.FLAT:
			# Flattened vertically
			if absf(rel.y) > r * 0.4:
				rel.y = signf(rel.y) * r * 0.4
			return center + Vector2(roundf(rel.x), roundf(rel.y))
		CanopyShape.COLUMNAR:
			# Narrow horizontally
			if absf(rel.x) > r * 0.4:
				rel.x = signf(rel.x) * r * 0.4
			return center + Vector2(roundf(rel.x), roundf(rel.y))

	return pos


func _init_spacing_grid() -> void:
	_spacing_grid.clear()

func _add_to_spacing_grid(pos: Vector2) -> void:
	var cell := float(maxi(cluster_min_spacing, 1))
	var key := Vector2i(floori(pos.x / cell), floori(pos.y / cell))
	if not _spacing_grid.has(key):
		_spacing_grid[key] = []
	_spacing_grid[key].append(pos)

func _check_spacing(pos: Vector2) -> bool:
	## Checks spacing via spatial grid — O(1) instead of O(n²).
	if cluster_min_spacing <= 0:
		return true
	var cell := float(cluster_min_spacing)
	var gx := floori(pos.x / cell)
	var gy := floori(pos.y / cell)
	var min_sq := float(cluster_min_spacing * cluster_min_spacing)
	for dx in range(-2, 3):
		for dy in range(-2, 3):
			var key := Vector2i(gx + dx, gy + dy)
			if _spacing_grid.has(key):
				for ex: Vector2 in _spacing_grid[key]:
					if pos.distance_squared_to(ex) < min_sq:
						return false
	return true


func _add_scatter_leaves(rng: RandomNumberGenerator, crown_center: Vector2, variant_count: int) -> void:
	## Adds small isolated pixels at canopy edges.
	## Finds the bounds, places points just beyond.
	for _i in scatter_amount:
		# Pick a random existing leaf and offset outward
		var base_leaf: Dictionary = _leaf_placements[rng.randi_range(0, _leaf_placements.size() - 1)]
		var base_pos: Vector2 = base_leaf["pos"]
		var dir_from_center := (base_pos - crown_center).normalized()
		if dir_from_center.length() < 0.1:
			dir_from_center = Vector2(rng.randf_range(-1, 1), rng.randf_range(-1, 0)).normalized()
		# Offset outward — distance proportional to scatter_amount
		# At 1: 3-5px, at 10: 6-14px, at 30: 10-24px
		var base_dist := 3.0 + float(scatter_amount) * 0.3
		var max_dist := 5.0 + float(scatter_amount) * 0.9
		var scatter_dist := rng.randf_range(base_dist, max_dist)
		var scatter_pos := base_pos + dir_from_center * scatter_dist
		scatter_pos += Vector2(rng.randf_range(-2.0, 2.0), rng.randf_range(-2.0, 2.0))
		scatter_pos = Vector2(roundf(scatter_pos.x), roundf(scatter_pos.y))

		_leaf_placements.append({
			"pos": scatter_pos,
			"layer": 1,  # toujours devant
			"tex_idx": rng.randi_range(0, variant_count - 1),
			"depth": 0,
			"is_scatter": true,
		})


# =============================================
#          HUE SHIFT (shared bake + draw)
# =============================================

func _calc_hue_shift_color(pos: Vector2, gradient_t: float, brightness: float, alpha: float) -> Color:
	## Computes the hue-shifted modulation for a leaf at this position.
	var shade_t := 1.0 - gradient_t  # 0 = haut (clair), 1 = bas (sombre)
	var x_range := _canopy_max_x - _canopy_min_x
	if x_range > 1.0:
		var x_t := clampf((pos.x - _canopy_min_x) / x_range, 0.0, 1.0)
		shade_t = clampf(shade_t * 0.6 + x_t * 0.4, 0.0, 1.0)

	# Target color based on diagonal position
	var target: Color
	if shade_t < 0.5:
		target = foliage_color_light.lerp(foliage_color_mid, shade_t * 2.0)
	else:
		target = foliage_color_mid.lerp(foliage_color_dark, (shade_t - 0.5) * 2.0)

	# HSV hue rotation: shadows → cool, highlights → warm
	var hue_rotate := (shade_t - 0.5) * hue_shift_amount * 0.08
	var h := fmod(target.h + hue_rotate + 1.0, 1.0)
	var s := clampf(target.s * (1.0 + hue_shift_amount * 0.15), 0.0, 1.0)
	var v := clampf(target.v * lerpf(1.0, lerpf(1.2, 0.7, shade_t), hue_shift_amount * 0.5), 0.0, 1.0)
	target = Color.from_hsv(h, s, v)

	# Target/mid ratio to preserve per-blob shading
	var mid := foliage_color_mid
	var tint := Color(
		target.r / maxf(mid.r, 0.01),
		target.g / maxf(mid.g, 0.01),
		target.b / maxf(mid.b, 0.01),
	)

	return Color(brightness * tint.r, brightness * tint.g, brightness * tint.b, alpha)


# =============================================
#     GLOBAL FOLIAGE OUTLINE (silhouette)
# =============================================

func _compute_foliage_outline() -> void:
	## Computes a 1px outline around the combined silhouette of all leaves.
	if _leaf_placements.is_empty():
		_foliage_outline_tex = null
		return

	# Leaf bounding box
	var min_x := INF
	var max_x := -INF
	var min_y := INF
	var max_y := -INF
	for leaf in _leaf_placements:
		var tex := _get_leaf_texture(leaf["tex_idx"])
		if not tex:
			continue
		var pos: Vector2 = leaf["pos"]
		var hw := tex.get_width() * 0.5
		var hh := tex.get_height() * 0.5
		min_x = minf(min_x, pos.x - hw)
		max_x = maxf(max_x, pos.x + hw)
		min_y = minf(min_y, pos.y - hh)
		max_y = maxf(max_y, pos.y + hh)

	# Margin for the outline
	min_x -= 2.0; min_y -= 2.0; max_x += 2.0; max_y += 2.0
	var w := ceili(max_x - min_x)
	var h := ceili(max_y - min_y)
	if w <= 0 or h <= 0:
		return
	_foliage_outline_offset = Vector2(min_x, min_y)

	# Create a mask: stamp all leaf textures
	var mask := Image.create(w, h, false, Image.FORMAT_LA8)
	var ox := -roundi(min_x)
	var oy := -roundi(min_y)
	for leaf in _leaf_placements:
		var tex := _get_leaf_texture(leaf["tex_idx"])
		if not tex:
			continue
		var pos: Vector2 = leaf["pos"]
		var src := tex.get_image()
		if not src:
			continue
		var draw_x := roundi(pos.x - tex.get_width() * 0.5) + ox
		var draw_y := roundi(pos.y - tex.get_height() * 0.5) + oy
		for y in src.get_height():
			var fy := draw_y + y
			if fy < 0 or fy >= h:
				continue
			for x in src.get_width():
				if src.get_pixel(x, y).a > 0.1:
					var fx := draw_x + x
					if fx >= 0 and fx < w:
						mask.set_pixel(fx, fy, Color(1, 1, 1, 1))

	# Detect edges: transparent pixels adjacent to opaque pixels
	var outline_img := Image.create(w, h, true, Image.FORMAT_RGBA8)
	var dirs: Array[Vector2i] = [
		Vector2i(-1, 0), Vector2i(1, 0), Vector2i(0, -1), Vector2i(0, 1),
		Vector2i(-1, -1), Vector2i(1, -1), Vector2i(-1, 1), Vector2i(1, 1)
	]
	for y in h:
		for x in w:
			if mask.get_pixel(x, y).a < 0.1:
				for d in dirs:
					var nx := x + d.x
					var ny := y + d.y
					if nx >= 0 and nx < w and ny >= 0 and ny < h:
						if mask.get_pixel(nx, ny).a > 0.1:
							outline_img.set_pixel(x, y, outline_color)
							break

	_foliage_outline_tex = ImageTexture.create_from_image(outline_img)


# =============================================
#              PROCESS + DRAW
# =============================================

func _process(delta: float) -> void:
	_time += delta
	queue_redraw()


var _trunk_tex_map: Dictionary = {}  # y_segment_index → image index (pre-computed)

func _build_trunk_tex_map() -> void:
	## Pre-computes which texture to use for each trunk height segment.
	## Randomized with the tree seed.
	_trunk_tex_map.clear()
	if _trunk_images.is_empty():
		return
	var rng := RandomNumberGenerator.new()
	rng.seed = _effective_seed + 777  # offset to avoid correlation with branches
	var h := trunk_tex_height
	if h <= 0 and _trunk_images[0]:
		h = _trunk_images[0].get_height()
	if h <= 0:
		h = 16
	# Number of segments across trunk height
	var segment_count := ceili(float(trunk_height) / float(h)) + 1
	for i in segment_count:
		_trunk_tex_map[i] = rng.randi_range(0, _trunk_images.size() - 1)


func _get_trunk_image_at(y_pos: int) -> Image:
	## Returns the trunk texture to use at this Y height.
	if _trunk_images.size() > 0:
		var abs_y := absi(y_pos)
		var h := trunk_tex_height
		if h <= 0 and _trunk_images[0]:
			h = _trunk_images[0].get_height()
		if h <= 0:
			h = 16
		@warning_ignore("integer_division")
		var seg_idx := abs_y / h
		if _trunk_tex_map and _trunk_tex_map.has(seg_idx):
			return _trunk_images[_trunk_tex_map[seg_idx]]
		return _trunk_images[0]
	return _trunk_image


func _calc_foliage_sway() -> float:
	return roundf(sin(_time * sway_speed) * sway_amplitude)


func _calc_trunk_sway() -> float:
	return roundf(sin(_time * sway_speed * 0.5) * sway_amplitude * 0.2)


func _get_segment_color(idx: int, total_w: int) -> Color:
	## 3-band color (light/mid/dark) based on width position.
	if total_w <= 1:
		return trunk_color_mid
	var ratio := float(idx) / float(total_w - 1)
	if ratio < 0.35:
		return trunk_color_light
	elif ratio > 0.65:
		return trunk_color_dark
	return trunk_color_mid


func _apply_trunk_gradient(base_color: Color, seg_y: float, branch_t: float = -1.0) -> Color:
	## Applies positional gradient (same system as foliage) to trunk colors.
	## Uses foliage_gradient and hue_shift_amount.
	## branch_t: if >= 0, uses this value (0=branch base, 1=tip) for hue shift
	## instead of absolute Y position. So all branch tips get the same shift.
	# gradient_t: 0 = base (sombre), 1 = sommet (clair) + variation par arbre
	var gradient_t := clampf(float(-seg_y) / float(maxi(trunk_height, 1)) + _shading_offset, 0.0, 1.0)

	# Brightness — same curve as foliage (always based on absolute Y position)
	var brightness := 1.0
	if foliage_gradient > 0.0:
		brightness = lerpf(1.0 - foliage_gradient * 0.4, 1.0 + foliage_gradient * 0.15, gradient_t)

	var result := Color(
		clampf(base_color.r * brightness, 0.0, 1.0),
		clampf(base_color.g * brightness, 0.0, 1.0),
		clampf(base_color.b * brightness, 0.0, 1.0),
		base_color.a
	)

	# Hue shift — shadows toward cool, highlights toward warm
	# For branches: uses branch_t (per-branch) so all
	# tips get the same hue shift, regardless of Y position.
	if hue_shift_amount > 0.0:
		var hue_t := gradient_t
		if branch_t >= 0.0:
			hue_t = branch_t  # 0 = trunk attachment, 1 = tip
		var shade_t := 1.0 - hue_t  # 0 = tip/top (clair), 1 = base/bottom (sombre)
		var hue_rotate := (shade_t - 0.5) * hue_shift_amount * 0.08
		var h := fmod(result.h + hue_rotate + 1.0, 1.0)
		var s := clampf(result.s * (1.0 + hue_shift_amount * 0.1), 0.0, 1.0)
		var v := clampf(result.v * lerpf(1.0, lerpf(1.1, 0.8, shade_t), hue_shift_amount * 0.3), 0.0, 1.0)
		result = Color.from_hsv(h, s, v, result.a)

	return result


func _blend_pixel(img: Image, x: int, y: int, col: Color) -> void:
	## Alpha blends a pixel onto the existing image.
	var dst := img.get_pixel(x, y)
	var out_a := col.a + dst.a * (1.0 - col.a)
	if out_a > 0.001:
		var out_r := (col.r * col.a + dst.r * dst.a * (1.0 - col.a)) / out_a
		var out_g := (col.g * col.a + dst.g * dst.a * (1.0 - col.a)) / out_a
		var out_b := (col.b * col.a + dst.b * dst.a * (1.0 - col.a)) / out_a
		img.set_pixel(x, y, Color(out_r, out_g, out_b, out_a))


# =============================================
#              BAKE TO TEXTURES
# =============================================

func _bake_all_layers() -> void:
	# Compute total bounding box
	var min_x: float = 0.0
	var max_x: float = 0.0
	var min_y: float = 0.0
	var max_y: float = 0.0

	for seg in _segments:
		var sw: int = seg["width"]
		if seg["is_trunk"]:
			min_x = minf(min_x, seg["x"] - 2.0)
			max_x = maxf(max_x, seg["x"] + float(sw) + 2.0)
			min_y = minf(min_y, seg["y"] - 2.0)
			max_y = maxf(max_y, seg["y"] + 2.0)
		else:
			# Branch: w×w square centered → extends w/2 in each direction
			var sh := float(sw) / 2.0
			min_x = minf(min_x, seg["x"] - sh - 2.0)
			max_x = maxf(max_x, seg["x"] + sh + 2.0)
			min_y = minf(min_y, seg["y"] - sh - 2.0)
			max_y = maxf(max_y, seg["y"] + sh + 2.0)

	for leaf in _leaf_placements:
		var tex := _get_leaf_texture(leaf["tex_idx"])
		if not tex:
			continue
		var hw := tex.get_width() * 0.5
		var hh := tex.get_height() * 0.5
		min_x = minf(min_x, leaf["pos"].x - hw - 4)
		max_x = maxf(max_x, leaf["pos"].x + hw + 4)
		min_y = minf(min_y, leaf["pos"].y - hh - 4)
		max_y = maxf(max_y, leaf["pos"].y + hh + 4)

	# Add margin for max sway
	var sway_margin := sway_amplitude + 4.0
	min_x -= sway_margin
	max_x += sway_margin

	_bake_offset = Vector2(min_x, min_y)
	_bake_size = Vector2i(ceili(max_x - min_x), ceili(max_y - min_y))
	if _bake_size.x <= 0 or _bake_size.y <= 0:
		return

	# Compute Y bands
	var total_y_min := min_y
	var total_y_max := max_y
	var band_height := (total_y_max - total_y_min) / float(BAKE_BANDS)
	_band_y_ranges.clear()
	for i in BAKE_BANDS:
		_band_y_ranges.append(Vector2(
			total_y_min + band_height * i,
			total_y_min + band_height * (i + 1)
		))

	# Bake the trunk
	var trunk_img := Image.create(_bake_size.x, _bake_size.y, true, Image.FORMAT_RGBA8)
	_bake_trunk(trunk_img)
	_baked_trunk = ImageTexture.create_from_image(trunk_img)

	# Bake leaf bands (if foliage enabled)
	_baked_leaves_bg.clear()
	_baked_leaves_fg.clear()
	if foliage_enabled:
		for i in BAKE_BANDS:
			var bg_img := Image.create(_bake_size.x, _bake_size.y, true, Image.FORMAT_RGBA8)
			_bake_leaves_band(bg_img, 0, _band_y_ranges[i].x, _band_y_ranges[i].y)
			_baked_leaves_bg.append(ImageTexture.create_from_image(bg_img))

			var fg_img := Image.create(_bake_size.x, _bake_size.y, true, Image.FORMAT_RGBA8)
			_bake_leaves_band(fg_img, 1, _band_y_ranges[i].x, _band_y_ranges[i].y)
			_baked_leaves_fg.append(ImageTexture.create_from_image(fg_img))

	_baked = true


func _bake_trunk(img: Image) -> void:
	var ox := -roundi(_bake_offset.x)
	var oy := -roundi(_bake_offset.y)
	var iw := img.get_width()
	var ih := img.get_height()

	# Outline
	if outline_enabled:
		for seg in _segments:
			var px := roundi(seg["x"]) + ox
			var py := roundi(seg["y"]) + oy
			var w: int = seg["width"]
			for dx in range(-1, 2):
				for dy in range(-1, 2):
					if dx == 0 and dy == 0:
						continue
					if not seg["is_trunk"]:
						# Branch: w×w square centered (with rounding)
						var half := w / 2
						var half_f := float(w - 1) * 0.5
						for bx in w:
							for by in w:
								if branch_round > 0.0 and w > 2:
									var da := float(bx) - half_f
									var db := float(by) - half_f
									var cheb := maxf(absf(da), absf(db))
									var eucl := sqrt(da * da + db * db)
									if lerpf(cheb, eucl, branch_round) > half_f + 0.5:
										continue
								var fx := px + bx - half + dx
								var fy := py + by - half + dy
								if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
									img.set_pixel(fx, fy, outline_color)
					else:
						for wx in w:
							var fx := px + wx + dx
							var fy := py + dy
							if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
								img.set_pixel(fx, fy, outline_color)

	# Glow (halo around trunk AND branches, drawn before segments)
	if branch_glow_intensity > 0.0:
		var glow_col := Color(branch_glow_color.r, branch_glow_color.g, branch_glow_color.b, branch_glow_color.a * branch_glow_intensity)
		for seg in _segments:
			var gpx := roundi(seg["x"]) + ox
			var gpy := roundi(seg["y"]) + oy
			var gw: int = seg["width"]
			if seg["is_trunk"]:
				# Trunk: glow around a w×1 band
				for gx in gw + 4:
					for gy in 5:
						var fx := gpx - 2 + gx
						var fy := gpy - 2 + gy
						if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
							_blend_pixel(img, fx, fy, glow_col)
			else:
				# Branch: glow around a w×w square
				var ghalf := gw / 2
				for gx in gw + 4:
					for gy in gw + 4:
						var fx := gpx + gx - ghalf - 2
						var fy := gpy + gy - ghalf - 2
						if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
							_blend_pixel(img, fx, fy, glow_col)

	# 2 passes: order depends on branch_behind_trunk
	# Pass 0 = what's behind, Pass 1 = what's in front
	for _draw_pass in 2:
		var draw_trunk: bool
		if branch_behind_trunk:
			draw_trunk = (_draw_pass == 1)  # pass 0 = branches, pass 1 = tronc
		else:
			draw_trunk = (_draw_pass == 0)  # pass 0 = tronc, pass 1 = branches

		if draw_trunk:
			# --- Tronc ---
			for seg in _segments:
				if not seg["is_trunk"]:
					continue
				var px := roundi(seg["x"]) + ox
				var py := roundi(seg["y"]) + oy
				var w: int = seg["width"]
				var active_img := _get_trunk_image_at(roundi(seg["y"]))
				if active_img:
					var tex_w := active_img.get_width()
					var tex_h := active_img.get_height()
					for wx in w:
						var tx := clampi(wx * tex_w / maxi(w, 1), 0, tex_w - 1)
						var ty := absi(roundi(seg["y"])) % tex_h
						var col := active_img.get_pixel(tx, ty)
						if trunk_gradient_shading:
							col = _apply_trunk_gradient(col, seg["y"])
						var fx := px + wx
						var fy := py
						if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
							img.set_pixel(fx, fy, col)
				else:
					for wx in w:
						var col := _get_segment_color(wx, w)
						if trunk_gradient_shading:
							col = _apply_trunk_gradient(col, seg["y"])
						var fx := px + wx
						var fy := py
						if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
							img.set_pixel(fx, fy, col)
		else:
			# --- Branches ---
			for seg in _segments:
				if seg["is_trunk"]:
					continue
				var px := roundi(seg["x"]) + ox
				var py := roundi(seg["y"]) + oy
				var w: int = seg["width"]
				var half := w / 2
				var half_f := float(w - 1) * 0.5
				var sv: bool = seg.get("shade_v", false)
				for a in w:
					var shade_a := a
					if branch_edge_shading and w > 2:
						shade_a = mini(a, w - 1 - a) * 2
					var col := _get_segment_color(shade_a, w)
					if trunk_gradient_shading:
						col = _apply_trunk_gradient(col, seg["y"], seg.get("branch_t", -1.0))
					for b in w:
						if branch_round > 0.0 and w > 2:
							var da := float(a) - half_f
							var db := float(b) - half_f
							var cheb := maxf(absf(da), absf(db))
							var eucl := sqrt(da * da + db * db)
							if lerpf(cheb, eucl, branch_round) > half_f + 0.5:
								continue
						var fx: int
						var fy: int
						if sv:
							fx = px + b - half
							fy = py + a - half
						else:
							fx = px + a - half
							fy = py + b - half
						if fx >= 0 and fx < iw and fy >= 0 and fy < ih:
							img.set_pixel(fx, fy, col)


func _bake_leaves_band(img: Image, layer: int, y_min: float, y_max: float) -> void:
	var ox := -roundi(_bake_offset.x)
	var oy := -roundi(_bake_offset.y)

	var canopy_range := _canopy_max_y - _canopy_min_y
	if canopy_range < 1.0:
		canopy_range = 1.0

	for leaf in _leaf_placements:
		if leaf["layer"] != layer:
			continue
		var pos: Vector2 = leaf["pos"]
		# Filtre par bande Y
		if pos.y < y_min or pos.y >= y_max:
			continue

		var tex := _get_leaf_texture(leaf["tex_idx"])
		if not tex:
			continue

		# Gradient vertical + variation par arbre
		var gradient_t := 1.0
		if absf(canopy_range) > 1.0:
			gradient_t = clampf((pos.y - _canopy_min_y) / canopy_range + _shading_offset, 0.0, 1.0)
			gradient_t = 1.0 - gradient_t

		var alpha := 1.0
		if leaf.has("is_scatter"):
			alpha = 0.85

		var brightness := 1.0
		if foliage_gradient > 0.0:
			brightness = lerpf(1.0 - foliage_gradient * 0.6, 1.0 + foliage_gradient * 0.25, gradient_t)
		if layer == 0:
			brightness *= 0.75

		# Calculer la modulation de couleur
		var mod_color: Color
		if hue_shift_amount > 0.0:
			mod_color = _calc_hue_shift_color(pos, gradient_t, brightness, alpha)
		else:
			mod_color = Color(brightness, brightness, brightness, alpha)

		# Blit la texture feuille dans l'image
		var draw_x := roundi(pos.x - tex.get_width() * 0.5) + ox
		var draw_y := roundi(pos.y - tex.get_height() * 0.5) + oy
		_blit_texture(img, tex, draw_x, draw_y, mod_color)


func _blit_texture(target: Image, tex: Texture2D, px: int, py: int, modulate: Color) -> void:
	var src_img := tex.get_image()
	if not src_img:
		return
	var sw := src_img.get_width()
	var sh := src_img.get_height()
	var tw := target.get_width()
	var th := target.get_height()

	for y in sh:
		var ty := py + y
		if ty < 0 or ty >= th:
			continue
		for x in sw:
			var tx := px + x
			if tx < 0 or tx >= tw:
				continue
			var src_col := src_img.get_pixel(x, y)
			if src_col.a < 0.01:
				continue
			# Appliquer la modulation
			var col := Color(
				src_col.r * modulate.r,
				src_col.g * modulate.g,
				src_col.b * modulate.b,
				src_col.a * modulate.a
			)
			# Alpha blending sur le pixel existant
			var dst := target.get_pixel(tx, ty)
			var out_a := col.a + dst.a * (1.0 - col.a)
			if out_a > 0.001:
				var out_r := (col.r * col.a + dst.r * dst.a * (1.0 - col.a)) / out_a
				var out_g := (col.g * col.a + dst.g * dst.a * (1.0 - col.a)) / out_a
				var out_b := (col.b * col.a + dst.b * dst.a * (1.0 - col.a)) / out_a
				target.set_pixel(tx, ty, Color(out_r, out_g, out_b, out_a))


func _draw() -> void:
	# Off-screen: draw nothing (0 draw calls)
	if not _on_screen and not Engine.is_editor_hint():
		return

	# Baked mode: textures with sway
	if _baked:
		var trunk_sway := _calc_trunk_sway()
		var foliage_sway := _calc_foliage_sway()

		# Global foliage outline (behind everything)
		if _foliage_outline_tex:
			draw_texture(_foliage_outline_tex, _foliage_outline_offset + Vector2(foliage_sway, 0))

		# Background leaves (3 bands)
		for i in _baked_leaves_bg.size():
			var band_sway := roundf(foliage_sway * _band_sway_factors[i])
			draw_texture(_baked_leaves_bg[i], _bake_offset + Vector2(band_sway, 0))

		# Trunk (medium sway)
		draw_texture(_baked_trunk, _bake_offset + Vector2(roundf(trunk_sway * 0.5), 0))

		# Light rays (remain dynamic)
		if light_rays_enabled and _light_rays.size() > 0:
			var ray_col := Color(light_rays_color.r, light_rays_color.g, light_rays_color.b, light_rays_opacity)
			for ray_poly in _light_rays:
				if ray_poly.size() < 4:
					continue
				var colors := PackedColorArray([
					ray_col, ray_col,
					Color(ray_col.r, ray_col.g, ray_col.b, 0.0),
					Color(ray_col.r, ray_col.g, ray_col.b, 0.0),
				])
				var swayed_poly := PackedVector2Array()
				for vi in ray_poly.size():
					var v: Vector2 = ray_poly[vi]
					var h_ratio := clampf(float(-v.y) / float(trunk_height + crown_radius), 0.0, 1.0)
					swayed_poly.append(Vector2(roundf(foliage_sway * h_ratio + v.x), v.y))
				draw_polygon(swayed_poly, colors)

		# Foreground leaves (3 bands)
		for i in _baked_leaves_fg.size():
			var band_sway := roundf(foliage_sway * _band_sway_factors[i])
			draw_texture(_baked_leaves_fg[i], _bake_offset + Vector2(band_sway, 0))
		return

	# Non-baked mode (editor @tool): original pixel-by-pixel rendering
	var trunk_sway := _calc_trunk_sway()
	var foliage_sway := _calc_foliage_sway()

	# === LAYER 0: global foliage outline ===
	if _foliage_outline_tex:
		draw_texture(_foliage_outline_tex, _foliage_outline_offset + Vector2(foliage_sway, 0))

	# === LAYER 0b: glow (trunk + branches) ===
	if branch_glow_intensity > 0.0:
		var glow_col := Color(branch_glow_color.r, branch_glow_color.g, branch_glow_color.b, branch_glow_color.a * branch_glow_intensity)
		for seg in _segments:
			var sx: float = seg["x"]
			var sy: float = seg["y"]
			var w: int = seg["width"]
			var height_ratio := clampf(float(-sy) / float(trunk_height), 0.0, 1.0)
			var seg_sway := roundf(trunk_sway * height_ratio)
			var px := roundi(sx + seg_sway)
			var py := roundi(sy)
			if not seg["is_trunk"]:
				var half := w / 2
				for dox in range(-2, 3):
					for doy in range(-2, 3):
						draw_rect(Rect2(Vector2(px - half + dox, py - half + doy), Vector2(w, w)), glow_col)
			else:
				for dox in range(-2, 3):
					for doy in range(-2, 3):
						draw_rect(Rect2(Vector2(px + dox, py + doy), Vector2(w, 1)), glow_col)

	# === LAYER 1: background leaves (layer 0) ===
	_draw_leaves(0, foliage_sway)

	# === LAYER 2: trunk/branch outline ===
	if outline_enabled:
		for seg in _segments:
			var sx: float = seg["x"]
			var sy: float = seg["y"]
			var w: int = seg["width"]
			var height_ratio := clampf(float(-sy) / float(trunk_height), 0.0, 1.0)
			var seg_sway := roundf(trunk_sway * height_ratio)
			var px := roundi(sx + seg_sway)
			var py := roundi(sy)
			for dox in range(-1, 2):
				for doy in range(-1, 2):
					if dox == 0 and doy == 0:
						continue
					if not seg["is_trunk"]:
						var half := w / 2
						var sv: bool = seg.get("shade_v", false)
						if branch_round > 0.0 and w > 2:
							var half_f := float(w - 1) * 0.5
							for oa in w:
								var da := absf(float(oa) - half_f)
								var max_r := half_f + 0.5
								var circle_r := sqrt(maxf(0.0, max_r * max_r - da * da))
								var round_r := lerpf(max_r, circle_r, branch_round)
								if round_r < 0.5:
									continue
								var bs := maxi(0, ceili(half_f - round_r))
								var bc := mini(w, floori(half_f + round_r) + 1) - bs
								if bc <= 0:
									continue
								if sv:
									draw_rect(Rect2(Vector2(px - half + bs + dox, py + oa - half + doy), Vector2(bc, 1)), outline_color)
								else:
									draw_rect(Rect2(Vector2(px + oa - half + dox, py - half + bs + doy), Vector2(1, bc)), outline_color)
						else:
							draw_rect(Rect2(Vector2(px - half + dox, py - half + doy), Vector2(w, w)), outline_color)
					else:
						draw_rect(Rect2(Vector2(px + dox, py + doy), Vector2(w, 1)), outline_color)

	# === LAYERS 3a/3b: trunk and branches (configurable order) ===
	for _draw_pass in 2:
		var draw_trunk: bool
		if branch_behind_trunk:
			draw_trunk = (_draw_pass == 1)  # pass 0 = branches, pass 1 = tronc
		else:
			draw_trunk = (_draw_pass == 0)  # pass 0 = tronc, pass 1 = branches

		if draw_trunk:
			# --- Tronc ---
			for seg in _segments:
				if not seg["is_trunk"]:
					continue
				var sx: float = seg["x"]
				var sy: float = seg["y"]
				var w: int = seg["width"]
				var height_ratio := clampf(float(-sy) / float(trunk_height), 0.0, 1.0)
				var seg_sway := roundf(trunk_sway * height_ratio)
				var px := roundi(sx + seg_sway)
				var py := roundi(sy)
				var active_img := _get_trunk_image_at(py)
				if active_img:
					var tex_w := active_img.get_width()
					var tex_h := active_img.get_height()
					for wx in w:
						var tx := clampi(wx * tex_w / maxi(w, 1), 0, tex_w - 1)
						var ty := absi(py) % tex_h
						var col := active_img.get_pixel(tx, ty)
						if trunk_gradient_shading:
							col = _apply_trunk_gradient(col, sy)
						draw_rect(Rect2(Vector2(px + wx, py), Vector2(1, 1)), col)
				else:
					for wx in w:
						var col := _get_segment_color(wx, w)
						if trunk_gradient_shading:
							col = _apply_trunk_gradient(col, sy)
						draw_rect(Rect2(Vector2(px + wx, py), Vector2(1, 1)), col)
		else:
			# --- Branches ---
			for seg in _segments:
				if seg["is_trunk"]:
					continue
				var sx: float = seg["x"]
				var sy: float = seg["y"]
				var w: int = seg["width"]
				var height_ratio := clampf(float(-sy) / float(trunk_height), 0.0, 1.0)
				var seg_sway := roundf(trunk_sway * height_ratio)
				var px := roundi(sx + seg_sway)
				var py := roundi(sy)
				var half := w / 2
				var half_f := float(w - 1) * 0.5
				var sv: bool = seg.get("shade_v", false)
				for a in w:
					var shade_a := a
					if branch_edge_shading and w > 2:
						shade_a = mini(a, w - 1 - a) * 2
					var col := _get_segment_color(shade_a, w)
					if trunk_gradient_shading:
						col = _apply_trunk_gradient(col, sy, seg.get("branch_t", -1.0))
					var b_start := 0
					var b_count := w
					if branch_round > 0.0 and w > 2:
						var da := absf(float(a) - half_f)
						var max_r := half_f + 0.5
						var circle_r := sqrt(maxf(0.0, max_r * max_r - da * da))
						var round_r := lerpf(max_r, circle_r, branch_round)
						if round_r < 0.5:
							continue
						b_start = maxi(0, ceili(half_f - round_r))
						b_count = mini(w, floori(half_f + round_r) + 1) - b_start
						if b_count <= 0:
							continue
					if sv:
						draw_rect(Rect2(Vector2(px - half + b_start, py + a - half), Vector2(b_count, 1)), col)
					else:
						draw_rect(Rect2(Vector2(px + a - half, py - half + b_start), Vector2(1, b_count)), col)

	# === LAYER 3c: light rays (between trunk and foreground leaves) ===
	if light_rays_enabled and _light_rays.size() > 0:
		var ray_col := Color(light_rays_color.r, light_rays_color.g, light_rays_color.b, light_rays_opacity)
		# Gradient color: opaque at top, transparent at bottom
		for ray_poly in _light_rays:
			if ray_poly.size() < 4:
				continue
			# ray_poly: [top_left, top_right, bottom_right, bottom_left]
			var colors := PackedColorArray([
				ray_col,
				ray_col,
				Color(ray_col.r, ray_col.g, ray_col.b, 0.0),  # bas = transparent
				Color(ray_col.r, ray_col.g, ray_col.b, 0.0),
			])
			# Apply foliage sway to rays (they move with the leaves)
			var swayed_poly := PackedVector2Array()
			for vi in ray_poly.size():
				var v: Vector2 = ray_poly[vi]
				var h_ratio := clampf(float(-v.y) / float(trunk_height + crown_radius), 0.0, 1.0)
				swayed_poly.append(Vector2(roundf(v.x + foliage_sway * h_ratio), v.y))
			draw_polygon(swayed_poly, colors)

	# === LAYER 4: foreground leaves (layer 1) ===
	_draw_leaves(1, foliage_sway)


func _draw_leaves(layer: int, sway: float) -> void:
	## Draws all leaves of a layer (0=bg, 1=fg).
	## Applies a vertical gradient (top = bright, bottom = dark).
	var canopy_range := _canopy_max_y - _canopy_min_y
	if canopy_range < 1.0:
		canopy_range = 1.0

	for leaf in _leaf_placements:
		if leaf["layer"] != layer:
			continue

		var tex := _get_leaf_texture(leaf["tex_idx"])
		if not tex:
			continue

		var pos: Vector2 = leaf["pos"]
		var height_ratio := clampf(float(-pos.y) / float(trunk_height + crown_radius), 0.0, 1.0)
		var leaf_sway := roundf(sway * height_ratio)

		var draw_pos := Vector2(
			roundf(pos.x + leaf_sway) - tex.get_width() * 0.5,
			roundf(pos.y) - tex.get_height() * 0.5
		)

		# --- Vertical gradient + per-tree variation ---
		# gradient_t: 1.0 = top of canopy (bright), 0.0 = bottom (dark)
		var gradient_t := 1.0
		if absf(canopy_range) > 1.0:
			gradient_t = clampf((pos.y - _canopy_min_y) / canopy_range + _shading_offset, 0.0, 1.0)
			gradient_t = 1.0 - gradient_t  # inverser : haut = 1, bas = 0

		# Scatter = slightly transparent
		var alpha := 1.0
		if leaf.has("is_scatter"):
			alpha = 0.85

		# --- Brightness gradient (toujours actif) ---
		var brightness := 1.0
		if foliage_gradient > 0.0:
			brightness = lerpf(1.0 - foliage_gradient * 0.6, 1.0 + foliage_gradient * 0.25, gradient_t)
		if layer == 0:
			brightness *= 0.75

		if hue_shift_amount > 0.0:
			var col := _calc_hue_shift_color(pos, gradient_t, brightness, alpha)
			draw_texture(tex, draw_pos, col)
		else:
			var col := Color(brightness, brightness, brightness, alpha)
			draw_texture(tex, draw_pos, col)
