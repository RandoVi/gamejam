class_name Player
extends CharacterBody2D

signal wall_entered
signal wall_exited

@export var flip_h: bool: set = set_flip_h

@export_group("Jump Input")

# Note: the acceleration/deceleration times in this group are ignored. Movement
# is inertia-free and the air has zero steering; the fields remain exported so
# existing scene overrides keep loading.
@export_group("Horizontal Movement")
@export var max_speed: float
@export_range(1.0, 5.0) var max_h_velocity_ratio: float # Multiplied by max_speed

@export_subgroup("On Floor")
@export_range(0.0, 1.0) var running_acc_time: float
@export_range(0.0, 1.0) var running_dec_time: float

@export_subgroup("In Air")
@export_range(0.0, 1.0) var jumping_acc_time: float
@export_range(0.0, 1.0) var jumping_dec_time: float
@export_range(0.0, 1.0) var falling_acc_time: float
@export_range(0.0, 1.0) var falling_dec_time: float

@export_group("Vertical Movement")
@export_subgroup("Gravity")
## Extra gravity while Jump is released during the ascent — this is what makes
## a tap shorter than a held jump. Guarded at use time so it can never be zero.
@export_range(1.0, 2.0) var jump_gravity_ratio: float = 1.6
@export_range(1.0, 2.0) var down_held_gravity_ratio: float
@export var gravity_limit: float
@export_range(1.0, 2.0) var down_held_gravity_limit_ratio: float

@export_subgroup("Jump")
@export var jump_height: float
@export_range(0.0, 1.0) var jump_time_to_peak: float
@export_range(0.0, 1.0) var jump_time_to_land: float
@export_range(1.0, 5.0) var max_up_velocity_ratio: float # Multiplied by jump_velocity
@export var jump_peak_boost: float # Boost applied to horizontal velocity after reaching jump peak
@export_range(0.0, 1.0) var jump_peak_gravity_ratio: float
@export var corner_correction_distance: int
@export var oneway_platform_assist_distance: int

@export_group("On Wall")
@export_subgroup("Wall Slide")
@export var max_wall_slide_speed: float
@export_range(1.0, 2.0) var down_held_wall_slide_ratio: float
@export_range(0.0, 1.0) var wall_slide_acc_time: float # Downward acceleration

@export_subgroup("Wall Jump")
@export_range(0.0, 1.0) var wall_jump_v_velocity_ratio: float # Multiplied by jump_velocity
@export var wall_jump_h_velocity: float
# Horizontal acceleration/deceleration after wall jumping.
@export_range(0.0, 1.0) var wall_jumping_acc_time: float
@export_range(0.0, 1.0) var wall_jumping_dec_time: float
@export_range(0.0, 1.0) var wall_jumping_towards_wall_dec_time: float # While the player is moving towards the wall

@export_group("Dash")
@export var dash_speed: float
@export var dash_distance: float
@export var after_dash_speed: float
@export_range(0.0, 1.0) var after_dash_gravity_ratio: float

@export_group("Animation")
@export_range(-90.0, 90.0, 0.1, "degrees") var max_move_skew: float
@export_range(0.0, 1.0) var shape_rescale_weight: float
@export var walk_animation_speed: float = 1.5

@export_group("Death And Respawn")
@export var death_duration: float = 0.15
@export var respawn_delay: float = 0.3

@export_group("Rhythm Jump")
@export var strong_jump_multiplier: float = 3
@export var normal_jump_multiplier: float = 2
@export var offbeat_jump_multiplier: float = 1

var dash_allowed: bool = false
var movement_enabled: bool = true
var _on_wall: bool = false: # This variable mustn't be edited manually
	set(value):
		if value != _on_wall:
			(wall_entered if value else wall_exited).emit()
		
		_on_wall = value

@onready var jump_velocity: float = -(2.0 * jump_height) / jump_time_to_peak
@onready var max_up_velocity: float = jump_velocity * max_up_velocity_ratio
@onready var max_h_velocity: float = max_speed * max_h_velocity_ratio
@onready var jumping_gravity: float = (2.0 * jump_height) / (jump_time_to_peak * jump_time_to_peak)
@onready var falling_gravity: float = (2.0 * jump_height) / (jump_time_to_land * jump_time_to_land)

@onready var shape: Node2D = $Shape as Node2D
@onready var state_machine: StateMachine = $StateMachine as StateMachine
@onready var collision_shape: CollisionShape2D = $CollisionShape2D as CollisionShape2D

@onready var player_sprite: AnimatedSprite2D = $Shape/AnimatedSprite2D as AnimatedSprite2D
@onready var particle_trails: CPUParticles2D = $ParticleTrails as CPUParticles2D
@onready var death_particles: CPUParticles2D = $DeathParticles as CPUParticles2D

@onready var jump_peak_gravity_timer: Timer = %JumpPeakGravity as Timer
@onready var jump_coyote_timer: Timer = %JumpCoyote as Timer
@onready var jump_buffer_timer: Timer = %JumpBuffer as Timer
@onready var wall_jump_coyote_timer: Timer = %WallJumpCoyote as Timer
@onready var wall_jump_buffer_timer: Timer = %WallJumpBuffer as Timer
@onready var dash_cooldown_timer: Timer = %DashCooldown as Timer
@onready var after_dash_gravity_timer: Timer = %AfterDashGravity as Timer

@onready var _default_shape_scale: Vector2 = shape.scale
@onready var _beat_manager = get_node_or_null("/root/BeatManager")

# When true, the jump's vertical arc is locked: apex/dash gravity modifiers and
# fast-fall stay disabled until the player lands. Horizontal velocity is never
# steered in the air (zero air control), so this only shapes vertical motion.
var jump_trajectory_locked: bool = false
var _pending_jump_multiplier: float = 1.0
var _default_spawn_position: Vector2

func _ready() -> void:
	_default_spawn_position = global_position

func _physics_process(_delta: float) -> void:
	if movement_enabled:
		_on_wall = is_on_wall()

func _process(_delta: float) -> void:
	update_animation()

func get_facing_dir() -> float:
	return -1.0 if flip_h else 1.0

func set_flip_h(value: bool) -> void:
	if not is_node_ready():
		await ready
	
	flip_h = value
	shape.scale.x = absf(shape.scale.x) * get_facing_dir()

func update_flip_h() -> void:
	# Facing only changes while the player has ground control; air steering is zero.
	if not is_on_floor():
		return
	
	var h_input_dir: float = signf(get_input_vector().x)
	
	if h_input_dir:
		flip_h = h_input_dir != 1.0

func get_input_vector() -> Vector2:
	return Input.get_vector("Left", "Right", "Up", "Down")

func apply_movement(_delta: float, _acc_time: float, _dec_time: float) -> void:
	# Inertia-free ground movement: full speed on the frame a direction is
	# pressed and a dead stop on the frame it is released. No acceleration,
	# deceleration or sliding; the acc/dec times are kept only so existing
	# state calls and scene overrides keep working.
	# Zero air control: in the air, horizontal velocity is only what the jump,
	# dash or wall jump set at takeoff. Input cannot change it until landing.
	if not is_on_floor():
		return
	
	velocity.x = max_speed * signf(get_input_vector().x)

func apply_gravity(delta: float) -> void:
	velocity.y += calculate_gravity() * delta
	velocity.y = clampf(velocity.y, max_up_velocity, calculate_gravity_limit())

func get_default_gravity() -> float:
	return falling_gravity if velocity.y >= 0.0 else jumping_gravity

## Gravity multiplier used when Jump is released during the ascent.
## Never allowed below 1.0: a 0.0 value here would cancel gravity entirely.
func get_jump_gravity_ratio() -> float:
	return maxf(jump_gravity_ratio, 1.0)

func calculate_gravity() -> float:
	if jump_trajectory_locked:
		# The vertical arc is locked, but the button still shapes the ascent:
		# releasing Jump while rising cuts the jump short.
		if velocity.y < 0.0 and not Input.is_action_pressed("Jump"):
			return get_default_gravity() * get_jump_gravity_ratio()
		
		return get_default_gravity()
	
	return get_default_gravity() * (
			jump_peak_gravity_ratio if not jump_peak_gravity_timer.is_stopped()
			else after_dash_gravity_ratio if not after_dash_gravity_timer.is_stopped()
			else get_jump_gravity_ratio() if velocity.y < 0.0 and not Input.is_action_pressed("Jump")
			else 1.0
	)

func calculate_gravity_limit() -> float:
	if jump_trajectory_locked:
		return gravity_limit
	
	return gravity_limit * (
			down_held_gravity_ratio if Input.is_action_pressed("Down") and velocity.y > 0
			else 1.0
	)

func jump() -> void:
	# Direction-based takeoff: Left/Right sets the horizontal velocity instantly,
	# so the jump never carries run momentum. No direction = straight up.
	var h_input_dir: float = signf(get_input_vector().x)
	if h_input_dir:
		flip_h = h_input_dir != 1.0
	velocity.x = h_input_dir * max_speed
	velocity.y = jump_velocity * _pending_jump_multiplier
	jump_trajectory_locked = true
	AudioManager.jump_sfx.play()
	_pending_jump_multiplier = 1.0

func get_jump_power_multiplier() -> float:
	if _beat_manager == null:
		return normal_jump_multiplier
	if _beat_manager.is_strong_beat():
		return strong_jump_multiplier
	if _beat_manager.is_on_beat():
		return normal_jump_multiplier
	return offbeat_jump_multiplier

func _capture_jump_power() -> void:
	_pending_jump_multiplier = get_jump_power_multiplier()

func _jump_triggered() -> bool:
	# Space and Up (W / Up arrow) both jump. The Left/Right held on this frame
	# sets the takeoff direction; Up alone is a straight-up jump.
	return Input.is_action_just_pressed("Jump") or Input.is_action_just_pressed("Up")

func try_jump() -> void:
	if _jump_triggered():
		_capture_jump_power()
		jump()

func try_coyote_jump() -> void:
	if not jump_coyote_timer.is_stopped():
		try_jump()

func try_jump_buffer_timer() -> void:
	if _jump_triggered():
		_capture_jump_power()
		jump_buffer_timer.start()

func try_buffer_jump() -> void:
	if not jump_buffer_timer.is_stopped():
		jump()

func stop_jump_timers() -> void:
	jump_coyote_timer.stop()
	jump_buffer_timer.stop()
	wall_jump_coyote_timer.stop()
	wall_jump_buffer_timer.stop()

func get_last_wall_dir() -> float:
	return -signf(get_wall_normal().x)

func apply_wall_slide(delta: float) -> void:
	if velocity.y <= 0.0:
		return

	var target_speed := calculate_wall_slide_speed()

	if wall_slide_acc_time <= 0.0:
		velocity.y = target_speed
		return

	var acceleration := max_wall_slide_speed / wall_slide_acc_time

	velocity.y = move_toward(
		velocity.y,
		target_speed,
		acceleration * delta
	)

func can_wall_slide() -> bool:
	if velocity.y <= 0.0:
		return false

	var input_dir: float = signf(get_input_vector().x)

	if input_dir == 0.0:
		return false

	# Check the wall in the direction the player is holding.
	return test_move(
		global_transform,
		Vector2(input_dir, 0.0)
	)

func try_wall_slide() -> void:
	if can_wall_slide():
		state_machine.activate_state_by_name("WallSlideState")

func calculate_wall_slide_speed() -> float:
	return max_wall_slide_speed * (
			down_held_wall_slide_ratio if Input.is_action_pressed("Down")
			else 1.0
	)

func wall_jump() -> void:
	var wall_jump_dir: float = -get_last_wall_dir()
	
	flip_h = wall_jump_dir != 1.0
	velocity.y = jump_velocity * wall_jump_v_velocity_ratio * _pending_jump_multiplier
	velocity.x = wall_jump_h_velocity * wall_jump_dir
	jump_trajectory_locked = true
	AudioManager.jump_sfx.play()
	_pending_jump_multiplier = 1.0
	
	state_machine.activate_state_by_name("WallJumpState")

func try_wall_jump(ignore_wall: bool = false) -> void:
	if _jump_triggered() and (is_on_wall() or ignore_wall):
		_capture_jump_power()
		wall_jump()

func try_coyote_wall_jump() -> void:
	if not wall_jump_coyote_timer.is_stopped():
		try_wall_jump(true)

func try_wall_jump_buffer_timer() -> void:
	if _jump_triggered():
		_capture_jump_power()
		wall_jump_buffer_timer.start()

func _on_wall_entered() -> void:
	if not wall_jump_buffer_timer.is_stopped():
		wall_jump()

func _on_wall_exited() -> void:
	if velocity.y > 0:
		wall_jump_coyote_timer.start()

func calculate_wall_jumping_dec_time() -> float:
	var h_input_dir: float = signf(get_input_vector().x)
	
	return (
			wall_jumping_towards_wall_dec_time if h_input_dir == get_last_wall_dir()
			else wall_jumping_dec_time
	)

func can_dash() -> bool:
	return dash_allowed and dash_cooldown_timer.is_stopped()

func try_dash() -> void:
	if Input.is_action_just_pressed("Dash") and can_dash():
		# The dash is aimed by the direction held on the dash frame.
		var h_input_dir: float = signf(get_input_vector().x)
		if h_input_dir:
			flip_h = h_input_dir != 1.0
		state_machine.activate_state_by_name("DashState")

func try_corner_correction(delta: float) -> void:
	var v_motion: Vector2 = Vector2(0.0, velocity.y * delta)
	
	if not test_move(global_transform, v_motion):
		return
	
	# Multiplied by 2 so each offset increments by 0.5 instead of 1.0.
	for offset_step: int in range(1, corner_correction_distance * 2 + 1):
		var offset: float = offset_step / 2.0
	
		for dir: float in [-1.0, 1.0]:
			var h_offset: Vector2 = Vector2(offset * dir, 0)
			var test_transform: Transform2D = global_transform.translated(h_offset)
			
			if not test_move(test_transform, v_motion):
				translate(h_offset)
				
				# Stop the player if they are moving opposite to the corner's direction.
				if velocity.x * dir < 0.0:
					velocity.x = 0.0
				
				return

func try_oneway_platform_assist() -> void:
	if test_move(global_transform, Vector2.DOWN):
		return
	
	# Multiplied by 2 so each offset increments by 0.5 instead of 1.0.
	for offset_step: int in range(oneway_platform_assist_distance * 2 + 1):
		var offset: float = offset_step / 2.0
		var v_offset: Vector2 = Vector2.UP * offset
		
		var test_transform: Transform2D = global_transform.translated(v_offset)
		
		if test_move(test_transform, Vector2.DOWN):
			# Make sure the player doesn't get stuck.
			if not test_move(test_transform, Vector2.UP):
				translate(v_offset)
			
			return

func apply_move_anim() -> void:
	var max_move_skew_rad: float = deg_to_rad(max_move_skew)
	
	shape.skew = remap(velocity.x, -max_speed, max_speed, -max_move_skew_rad, max_move_skew_rad)

func update_shape_scale(delta: float) -> void:
	var target: Vector2 = _default_shape_scale * shape.scale.sign()
	var frame_weight: float = 1.0 - pow(1.0 - shape_rescale_weight, 60.0 * delta)
	
	shape.scale = shape.scale.lerp(target, frame_weight)

func update_animation() -> void:
	if not movement_enabled:
		return
	
	if not is_on_floor():
		play_animation(&"Jump")
		particle_trails.emitting = false
	elif absf(velocity.x) > 10.0:
		play_animation(&"Walk", walk_animation_speed)
		particle_trails.emitting = true
	else:
		play_animation(&"Idle")
		particle_trails.emitting = false

func play_animation(animation_name: StringName, speed_scale: float = 1.0) -> void:
	if player_sprite.animation != animation_name or not player_sprite.is_playing():
		player_sprite.play(animation_name)
	
	player_sprite.speed_scale = speed_scale

func get_spawn_point() -> Node2D:
	var spawn: Node2D = get_node_or_null("%SpawnPoint") as Node2D
	
	if not spawn:
		var current_scene: Node = get_tree().current_scene
		if current_scene:
			spawn = current_scene.get_node_or_null("%SpawnPoint") as Node2D
	
	return spawn

func get_respawn_position() -> Vector2:
	var spawn: Node2D = get_spawn_point()
	
	return spawn.global_position if spawn else _default_spawn_position

func get_default_shape_scale() -> Vector2:
	return Vector2(absf(_default_shape_scale.x) * get_facing_dir(), _default_shape_scale.y)

# Shrinks the player then respawns it at the level's spawn point.
# Also called by LevelFinishDoor so the player visually enters the door.
func death_tween() -> void:
	if not movement_enabled:
		return
	
	movement_enabled = false
	velocity = Vector2.ZERO
	particle_trails.emitting = false
	state_machine.process_mode = Node.PROCESS_MODE_DISABLED
	
	var shrink_tween: Tween = create_tween()
	shrink_tween.tween_property(shape, "scale", Vector2.ZERO, death_duration)
	await shrink_tween.finished
	
	if not is_inside_tree():
		return
	
	global_position = get_respawn_position()
	velocity = Vector2.ZERO
	jump_trajectory_locked = false
	_pending_jump_multiplier = 1.0
	_on_wall = false
	stop_jump_timers()
	
	await get_tree().create_timer(respawn_delay).timeout
	
	if not is_inside_tree():
		return
	
	AudioManager.respawn_sfx.play()
	
	var grow_tween: Tween = create_tween()
	grow_tween.tween_property(shape, "scale", get_default_shape_scale(), death_duration)
	await grow_tween.finished
	
	if not is_inside_tree():
		return
	
	movement_enabled = true
	# Reset from a clean slate. The state that was active at death may be
	# FallState; re-entering it through AirEntryState used to be skipped, which
	# left the machine stuck in AirEntryState (no physics) after respawning.
	state_machine.reset_to("AirEntryState")
	state_machine.process_mode = Node.PROCESS_MODE_INHERIT

# --------- SIGNALS ---------- #

# Reset the player's position to the current level spawn point if collided with any trap
func _on_collision_body_entered(body: Node) -> void:
	if body.is_in_group("Traps") and movement_enabled:
		AudioManager.death_sfx.play()
		death_particles.emitting = true
		death_tween()
