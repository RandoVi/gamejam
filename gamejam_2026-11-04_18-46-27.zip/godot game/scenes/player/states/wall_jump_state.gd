class_name WallJumpState
extends PlayerState

func _enter(_previous_state: State) -> void:
	player.stop_jump_timers()
	player.dash_allowed = true

func _physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	player.apply_movement(delta, player.wall_jumping_acc_time, player.calculate_wall_jumping_dec_time())
	player.try_wall_jump()
	player.try_dash()
	player.try_corner_correction(delta)
	player.update_flip_h()
	player.apply_move_anim()
	player.update_shape_scale(delta)
	
	player.move_and_slide()
	
	if player.velocity.y >= 0:
		switch_to("FallState")
	elif player.is_on_floor():
		switch_to("FloorEntryState")
	elif player.can_wall_slide():
		switch_to("WallSlideState")
