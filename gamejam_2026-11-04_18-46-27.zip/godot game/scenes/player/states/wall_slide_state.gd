
class_name WallSlideState
extends PlayerState

func _enter(_previous_state: State) -> void:
	player.dash_allowed = true

func _physics_update(delta: float) -> void:
	var wall_dir: float = player.get_last_wall_dir()
	var input_dir: float = signf(player.get_input_vector().x)

	# Keep pushing into the wall so move_and_slide maintains wall contact.
	if input_dir == wall_dir:
		player.velocity.x = wall_dir * player.max_speed

	player.apply_wall_slide(delta)

	# Preserve all existing jump mechanics.
	player.try_wall_jump()
	player.try_coyote_wall_jump()
	player.try_wall_jump_buffer_timer()
	player.try_dash()

	player.try_corner_correction(delta)
	player.apply_move_anim()
	player.update_shape_scale(delta)

	player.move_and_slide()

	if player.is_on_floor():
		switch_to("FloorEntryState")
	elif player.velocity.y < 0.0:
		switch_to("JumpState")
	elif not player.is_on_wall() or input_dir != player.get_last_wall_dir():
		player.velocity.x = 0.0
		switch_to("FallState")
