class_name FallState
extends PlayerState

func _physics_update(delta: float) -> void:
	player.apply_gravity(delta)
	player.apply_movement(delta, player.falling_acc_time, player.falling_dec_time)
	player.try_coyote_jump()
	player.try_jump_buffer_timer()
	player.try_wall_jump()
	player.try_coyote_wall_jump()
	player.try_wall_jump_buffer_timer()
	player.try_dash()
	player.update_flip_h()
	player.apply_move_anim()
	player.update_shape_scale(delta)

	player.move_and_slide()

	if player.is_on_floor():
		switch_to("FloorEntryState")
	elif player.velocity.y < 0.0:
		switch_to("JumpState")
	elif player.can_wall_slide():
		switch_to("WallSlideState")
